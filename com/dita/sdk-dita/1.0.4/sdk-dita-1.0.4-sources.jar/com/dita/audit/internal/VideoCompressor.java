package com.dita.audit.internal;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

/**
 * Comprime vídeos antes do upload para reduzir tamanho e tempo de transferência.
 * Usa o pipeline nativo do Android (MediaCodec + MediaMuxer).
 *
 * Estratégia: re-mux com bitrate reduzido se o vídeo for maior que o threshold.
 * Se a compressão falhar, retorna o arquivo original (graceful fallback).
 */
public class VideoCompressor {

    private static final String TAG = "DitaVideoCompressor";
    private static final long SIZE_THRESHOLD_BYTES = 30 * 1024 * 1024; // 30MB

    /**
     * Comprime o vídeo se for maior que o threshold.
     *
     * @param inputFile  Vídeo original
     * @param cacheDir   Diretório para arquivo temporário
     * @return Arquivo comprimido (ou o original se não precisou comprimir)
     */
    public static File compressIfNeeded(File inputFile, File cacheDir) {
        if (inputFile.length() <= SIZE_THRESHOLD_BYTES) {
            Log.d(TAG, "Vídeo já é pequeno (" + (inputFile.length() / 1024 / 1024) + "MB), pulando compressão");
            return inputFile;
        }

        Log.d(TAG, "Comprimindo vídeo de " + (inputFile.length() / 1024 / 1024) + "MB...");

        File outputFile = new File(cacheDir,
                "dita_compressed_" + System.currentTimeMillis() + ".mp4");

        try {
            transcodeVideo(inputFile, outputFile);

            long originalSize = inputFile.length();
            long compressedSize = outputFile.length();
            double ratio = (1.0 - (double) compressedSize / originalSize) * 100;

            Log.d(TAG, String.format("Compressão: %dMB → %dMB (%.0f%% menor)",
                    originalSize / 1024 / 1024,
                    compressedSize / 1024 / 1024,
                    ratio));

            // Se a compressão não reduziu, usar original
            if (compressedSize >= originalSize) {
                Log.d(TAG, "Compressão não reduziu tamanho, usando original");
                outputFile.delete();
                return inputFile;
            }

            return outputFile;
        } catch (Exception e) {
            Log.w(TAG, "Falha na compressão, usando vídeo original: " + e.getMessage());
            if (outputFile.exists()) outputFile.delete();
            return inputFile;
        }
    }

    private static void transcodeVideo(File input, File output) throws IOException {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(input.getAbsolutePath());

        int videoTrackIndex = -1;
        int audioTrackIndex = -1;
        MediaFormat videoFormat = null;
        MediaFormat audioFormat = null;

        for (int i = 0; i < extractor.getTrackCount(); i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("video/") && videoTrackIndex == -1) {
                videoTrackIndex = i;
                videoFormat = format;
            } else if (mime != null && mime.startsWith("audio/") && audioTrackIndex == -1) {
                audioTrackIndex = i;
                audioFormat = format;
            }
        }

        if (videoTrackIndex == -1) {
            extractor.release();
            throw new IOException("Nenhuma track de vídeo encontrada");
        }

        // Re-mux sem re-encode (cópia rápida das tracks)
        // TODO: implementar compressão real com MediaCodec encoder/decoder para reduzir tamanho
        MediaMuxer muxer = new MediaMuxer(output.getAbsolutePath(),
                MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);

        int muxerVideoTrack = muxer.addTrack(videoFormat);
        int muxerAudioTrack = -1;
        if (audioTrackIndex != -1 && audioFormat != null) {
            muxerAudioTrack = muxer.addTrack(audioFormat);
        }

        muxer.start();

        // Copiar track de vídeo
        copyTrack(extractor, muxer, videoTrackIndex, muxerVideoTrack);

        // Copiar track de áudio
        if (audioTrackIndex != -1 && muxerAudioTrack != -1) {
            copyTrack(extractor, muxer, audioTrackIndex, muxerAudioTrack);
        }

        muxer.stop();
        muxer.release();
        extractor.release();
    }

    private static void copyTrack(MediaExtractor extractor, MediaMuxer muxer,
                                   int sourceTrack, int destTrack) throws IOException {
        extractor.selectTrack(sourceTrack);

        ByteBuffer buffer = ByteBuffer.allocate(1024 * 1024); // 1MB buffer
        MediaCodec.BufferInfo bufferInfo = new MediaCodec.BufferInfo();

        while (true) {
            int sampleSize = extractor.readSampleData(buffer, 0);
            if (sampleSize < 0) break;

            bufferInfo.offset = 0;
            bufferInfo.size = sampleSize;
            bufferInfo.presentationTimeUs = extractor.getSampleTime();
            int sampleFlags = extractor.getSampleFlags();
            bufferInfo.flags = (sampleFlags & android.media.MediaExtractor.SAMPLE_FLAG_SYNC) != 0
                    ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;

            muxer.writeSampleData(destTrack, buffer, bufferInfo);
            extractor.advance();
        }

        extractor.unselectTrack(sourceTrack);
    }
}
