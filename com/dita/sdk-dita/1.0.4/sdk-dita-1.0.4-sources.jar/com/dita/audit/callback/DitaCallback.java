package com.dita.audit.callback;

import com.dita.audit.model.AuditResult;

/**
 * Callback principal do SDK Dita.
 * Implementado pelo app consumidor para receber o resultado da auditoria.
 */
public interface DitaCallback {

    /**
     * Chamado quando a auditoria é concluída com sucesso.
     *
     * @param result Resultado completo da auditoria
     */
    void onResult(AuditResult result);

    /**
     * Chamado quando ocorre um erro durante o processo.
     *
     * @param error Detalhes do erro
     */
    void onError(DitaError error);

    /**
     * Chamado quando o progresso da operação muda.
     * Opcional — implementação padrão vazia.
     *
     * @param step  Etapa atual (ex: "RECORDING_VIDEO_1", "UPLOADING", "PROCESSING")
     * @param progress Percentual de progresso (0-100), -1 se indeterminado
     */
    default void onProgress(String step, int progress) {
        // Opcional
    }
}
