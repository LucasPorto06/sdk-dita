package com.dita.audit.model;

/**
 * Status final da auditoria.
 * Cada valor contém uma chave (key) e descrição legível (label).
 */
public enum AuditStatus {

    APPROVED(0, "Aprovado"),
    REJECTED(1, "Reprovado"),
    NEEDS_REVIEW(2, "Necessita revisão"),
    PROCESSING(3, "Em processamento"),
    FAILED(4, "Erro no processamento");

    private final int key;
    private final String label;

    AuditStatus(int key, String label) {
        this.key = key;
        this.label = label;
    }

    public int getKey() {
        return key;
    }

    public String getLabel() {
        return label;
    }

    /**
     * Converte a string retornada pela API em AuditStatus.
     */
    public static AuditStatus fromApiValue(String value) {
        if (value == null) return PROCESSING;
        switch (value) {
            case "DONE_APPROVED":
                return APPROVED;
            case "DONE_REJECTED":
                return REJECTED;
            case "DONE_NEEDS_REVIEW":
                return NEEDS_REVIEW;
            case "FAILED":
                return FAILED;
            default:
                return PROCESSING;
        }
    }
}
