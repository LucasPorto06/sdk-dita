package com.dita.audit.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Checklist de detecções de um vídeo específico.
 * Contém as peças detectadas com confiança e o score do vídeo.
 */
public class VideoChecklist {

    private final int videoIndex;
    private final String videoType;
    private final int score;
    private final int totalParts;
    private final int detectedCount;
    private final List<PartDetection> parts;

    public VideoChecklist(int videoIndex, String videoType, int score,
                          int totalParts, int detectedCount, List<PartDetection> parts) {
        this.videoIndex = videoIndex;
        this.videoType = videoType;
        this.score = score;
        this.totalParts = totalParts;
        this.detectedCount = detectedCount;
        this.parts = parts != null ? parts : new ArrayList<>();
    }

    /** Índice do vídeo (1 = fechado, 2 = aberto) */
    public int getVideoIndex() { return videoIndex; }

    /** Tipo do vídeo: "CLOSED" ou "OPEN" */
    public String getVideoType() { return videoType; }

    /** Score composto do vídeo (0-100) */
    public int getScore() { return score; }

    /** Total de peças possíveis (21) */
    public int getTotalParts() { return totalParts; }

    /** Quantidade de peças detectadas */
    public int getDetectedCount() { return detectedCount; }

    /** Lista de peças com status de detecção */
    public List<PartDetection> getParts() { return parts; }

    /** Label legível: "Vídeo #1 — Fechado" */
    public String getLabel() {
        String tipo = "CLOSED".equals(videoType) ? "Fechado" : "Aberto";
        return "Vídeo #" + videoIndex + " — " + tipo;
    }

    /** Resumo: "19/21" */
    public String getResumo() {
        return detectedCount + "/" + totalParts;
    }

    /** Status: "DONE" se todas detectadas */
    public boolean isCompleto() {
        return detectedCount >= totalParts;
    }

    /**
     * Detecção individual de uma peça.
     */
    public static class PartDetection {
        private final String part;
        private final String displayName;
        private final boolean detected;
        private final double confidence;

        public PartDetection(String part, String displayName, boolean detected, double confidence) {
            this.part = part;
            this.displayName = displayName;
            this.detected = detected;
            this.confidence = confidence;
        }

        /** Label original em inglês (ex: "Headlight") */
        public String getPart() { return part; }

        /** Nome em pt-BR (ex: "Farol") */
        public String getDisplayName() { return displayName; }

        /** Se a peça foi detectada */
        public boolean isDetected() { return detected; }

        /** Confiança da detecção (0.0 a 1.0) */
        public double getConfidence() { return confidence; }

        /** Confiança formatada: "95%" */
        public String getConfidenceFormatted() {
            return String.format("%.0f%%", confidence * 100);
        }
    }
}
