package com.dita.audit;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Dados da vistoria a ser iniciada.
 * Utilizar o {@link Builder} para construir.
 */
public class InspectionData {

    private final String plate;
    private final String chassis;
    private final String vehicle;
    private final String store;
    private final String inspector;
    private final Map<String, String> extras;

    private InspectionData(Builder builder) {
        this.plate = builder.plate;
        this.chassis = builder.chassis;
        this.vehicle = builder.vehicle;
        this.store = builder.store;
        this.inspector = builder.inspector;
        this.extras = Collections.unmodifiableMap(new HashMap<>(builder.extras));
    }

    public String getPlate() { return plate; }
    public String getChassis() { return chassis; }
    public String getVehicle() { return vehicle; }
    public String getStore() { return store; }
    public String getInspector() { return inspector; }
    public Map<String, String> getExtras() { return extras; }
    public String getExtra(String key) { return extras.get(key); }

    public static class Builder {
        private String plate;
        private String chassis;
        private String vehicle;
        private String store;
        private String inspector;
        private final Map<String, String> extras = new HashMap<>();

        public Builder plate(String plate) {
            this.plate = plate;
            return this;
        }

        public Builder chassis(String chassis) {
            this.chassis = chassis;
            return this;
        }

        public Builder vehicle(String vehicle) {
            this.vehicle = vehicle;
            return this;
        }

        public Builder store(String store) {
            this.store = store;
            return this;
        }

        public Builder inspector(String inspector) {
            this.inspector = inspector;
            return this;
        }

        public Builder extra(String key, String value) {
            this.extras.put(key, value);
            return this;
        }

        public Builder extras(Map<String, String> extras) {
            if (extras != null) this.extras.putAll(extras);
            return this;
        }

        public InspectionData build() {
            return new InspectionData(this);
        }
    }
}
