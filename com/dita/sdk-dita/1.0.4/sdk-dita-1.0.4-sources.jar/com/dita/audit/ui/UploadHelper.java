package com.dita.audit.ui;

import android.util.Log;

import com.dita.audit.DitaAudit;
import com.dita.audit.callback.DitaCallback;
import com.dita.audit.detection.Detection;
import com.dita.audit.detection.VehiclePart;
import com.dita.audit.detection.VehiclePartProcessor;
import com.dita.audit.internal.ApiClient;
import com.dita.audit.internal.VideoCompressor;
import com.dita.audit.model.AuditItemDetail;
import com.dita.audit.model.AuditResult;
import com.dita.audit.model.AuditStatus;
import com.dita.audit.model.FsmValidation;
import com.dita.audit.model.ScoreBreakdown;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Executa o fluxo de upload e processamento em background.
 *
 * <p>Responsabilidades: comprimir vídeos, enviar detecções YOLO,
 * fazer upload paralelo para GCS, submeter inspeção e fazer polling
 * do resultado. Nenhuma operação de UI é feita aqui — toda comunicação
 * com a Activity é via callbacks package-private.</p>
 */
class UploadHelper {

    private static final String TAG = "UploadHelper";

    private final CaptureActivity activity;
    private final VehiclePartProcessor processor;
    private final File video1;
    private final File video2;
    private final long recordingStartTime;

    UploadHelper(CaptureActivity activity, VehiclePartProcessor processor,
                 File video1, File video2, long recordingStartTime) {
        this.activity = activity;
        this.processor = processor;
        this.video1 = video1;
        this.video2 = video2;
        this.recordingStartTime = recordingStartTime;
    }

    /**
     * Executa o fluxo completo. Deve ser chamado em background thread.
     * Lança exceção se qualquer etapa falhar.
     */
    void execute() throws Exception {
        ApiClient api = DitaAudit.getInstance().getApiClient();
        String inspectionId = DitaAudit.getInstance().getCurrentInspectionId();

        validateState(api, inspectionId);
        sendDetections(api, inspectionId);
        File[] compressed = compressVideos();
        checkCancelled();
        uploadVideosParallel(api, inspectionId, compressed[0], compressed[1]);
        checkCancelled();
        submitAndPoll(api, inspectionId);
    }

    // ─── Etapas ──────────────────────────────────────────────────

    private void validateState(ApiClient api, String inspectionId) throws Exception {
        if (api == null) throw new Exception("ApiClient não inicializado");
        if (inspectionId == null || inspectionId.isEmpty()) {
            throw new Exception("inspectionId não disponível — inspeção pode não ter sido criada");
        }
        if (video1 == null || !video1.exists() || video1.length() == 0) {
            throw new Exception("Vídeo 1 não encontrado ou vazio");
        }
        if (video2 == null || !video2.exists() || video2.length() == 0) {
            throw new Exception("Vídeo 2 não encontrado ou vazio");
        }
    }

    private void sendDetections(ApiClient api, String inspectionId) {
        activity.updateProcessingStatus("Enviando detecções…", 3);
        try {
            JSONObject payload = buildDetectionsPayload();
            api.sendSdkDetections(inspectionId, payload);

            JSONObject rawLog = buildRawYoloLog();
            sendAuditLog(api, inspectionId, "INFO", "SDK_YOLO_RAW",
                    "YOLO raw output", rawLog);
        } catch (Exception e) {
            Log.w(TAG, "Falha ao enviar detecções (best-effort): " + e.getMessage());
        }
    }

    private File[] compressVideos() throws Exception {
        activity.updateProcessingStatus("Comprimindo vídeos…", 5);
        File c1 = VideoCompressor.compressIfNeeded(video1, activity.getCacheDir());
        File c2 = VideoCompressor.compressIfNeeded(video2, activity.getCacheDir());
        return new File[]{c1, c2};
    }

    private void uploadVideosParallel(ApiClient api, String inspectionId,
                                       File compressed1, File compressed2) throws Exception {
        activity.updateProcessingStatus("Enviando vídeos…", 15);
        ExecutorService pool = Executors.newFixedThreadPool(2);
        AtomicReference<Exception> error = new AtomicReference<>();
        CountDownLatch latch = new CountDownLatch(2);

        pool.execute(() -> {
            try {
                uploadSingleVideo(api, inspectionId, 1, compressed1);
            } catch (Exception e) {
                error.compareAndSet(null, e);
            } finally {
                latch.countDown();
            }
        });

        pool.execute(() -> {
            try {
                uploadSingleVideo(api, inspectionId, 2, compressed2);
            } catch (Exception e) {
                error.compareAndSet(null, e);
            } finally {
                latch.countDown();
            }
        });

        boolean done = latch.await(5, TimeUnit.MINUTES);
        pool.shutdown();
        if (!done) throw new Exception("Upload timeout — excedeu 5 minutos");
        if (error.get() != null) throw error.get();
    }

    private void uploadSingleVideo(ApiClient api, String inspectionId,
                                    int videoIndex, File videoFile) throws Exception {
        String[] info = api.getUploadUrl(inspectionId, videoIndex, videoFile.length());
        String signedUrl = info[0];
        String storageKey = info[1];

        api.uploadVideoToGcs(signedUrl, videoFile);

        long durationMs = System.currentTimeMillis() - recordingStartTime;
        String videoType = (videoIndex == 1) ? "CLOSED" : "OPEN";
        api.confirmUpload(inspectionId, videoIndex, storageKey, durationMs, videoType);
    }

    private void submitAndPoll(ApiClient api, String inspectionId) throws Exception {
        activity.updateProcessingStatus("Processando…", 70);
        api.submitInspection(inspectionId);

        notifyProgress("PROCESSING", 80);

        AuditResult result = pollForResult(api, inspectionId);
        activity.onUploadComplete(result);
    }

    // ─── Polling ─────────────────────────────────────────────────

    private AuditResult pollForResult(ApiClient api, String inspectionId) throws Exception {
        long startTime = System.currentTimeMillis();
        long timeout = DitaAudit.getInstance().getConfig().getPollingTimeoutMs();
        long interval = DitaAudit.getInstance().getConfig().getPollingIntervalMs();

        while (System.currentTimeMillis() - startTime < timeout) {
            checkCancelled();
            try {
                JSONObject status = api.getInspectionStatus(inspectionId);
                String auditStatus = status.optString("auditStatus", "PENDING");

                if (auditStatus.startsWith("DONE_") || auditStatus.equals("FAILED")) {
                    return ResultParser.parse(inspectionId, status);
                }

                activity.updateProcessingStatus("Processando…", -1);
                Thread.sleep(interval);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new Exception("Polling interrompido");
            }
        }

        return new AuditResult.Builder()
                .inspectionId(inspectionId)
                .status(AuditStatus.PROCESSING)
                .score(0)
                .build();
    }

    // ─── Payload builders ────────────────────────────────────────

    private JSONObject buildDetectionsPayload() throws Exception {
        JSONArray arr = new JSONArray();
        Map<String, VehiclePart> parts = processor.getPartsMap();

        for (String label : Detection.LABELS) {
            JSONObject det = new JSONObject();
            det.put("part", label);

            VehiclePart part = parts.get(label);
            if (part != null) {
                det.put("detected", true);
                det.put("confidence", part.getMaxConfidence());
                det.put("detectionCount", part.getDetectionCount());
                det.put("firstDetectedAt", part.getFirstDetectedAt());
                det.put("lastDetectedAt", part.getLastDetectedAt());
            } else {
                det.put("detected", false);
                det.put("confidence", 0);
                det.put("detectionCount", 0);
                det.put("firstDetectedAt", 0);
                det.put("lastDetectedAt", 0);
            }
            arr.put(det);
        }

        JSONObject payload = new JSONObject();
        payload.put("videoIndex", 0);
        payload.put("detections", arr);
        payload.put("modelVersion", "yolo_custom_fp16");
        payload.put("processedAt", System.currentTimeMillis());
        return payload;
    }

    private JSONObject buildRawYoloLog() throws Exception {
        JSONObject result = new JSONObject();
        result.put("modelVersion", "yolo_custom_fp16");
        result.put("uniquePartsDetected", processor.getUniquePartsCount());
        return result;
    }

    private void sendAuditLog(ApiClient api, String inspectionId,
                               String level, String stage, String message, JSONObject details) {
        try {
            JSONObject body = new JSONObject();
            body.put("level", level);
            body.put("stage", stage);
            body.put("message", message);
            body.put("details", details);

            String url = DitaAudit.getInstance().getConfig().getApiBaseUrl()
                    + "/inspections/" + inspectionId + "/logs";
            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(url)
                    .post(okhttp3.RequestBody.create(body.toString(),
                            okhttp3.MediaType.parse("application/json")))
                    .addHeader("Authorization", "Bearer "
                            + DitaAudit.getInstance().getConfig().getApiKey())
                    .build();

            try (okhttp3.Response response = new okhttp3.OkHttpClient().newCall(request).execute()) {
                // best-effort
            }
        } catch (Exception e) {
            Log.w(TAG, "Erro ao enviar AuditLog: " + e.getMessage());
        }
    }

    // ─── Utilitários ─────────────────────────────────────────────

    private void checkCancelled() throws Exception {
        if (DitaAudit.getInstance().isCancelled()) {
            throw new Exception("Vistoria cancelada");
        }
    }

    private void notifyProgress(String stage, int progress) {
        DitaCallback cb = DitaAudit.getInstance().getCurrentCallback();
        if (cb != null) {
            activity.runOnUiThread(() -> cb.onProgress(stage, progress));
        }
    }
}
