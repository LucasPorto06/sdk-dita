package com.dita.audit.ui;

import android.util.Log;

import com.dita.audit.model.AuditItemDetail;
import com.dita.audit.model.AuditResult;
import com.dita.audit.model.AuditStatus;
import com.dita.audit.model.FsmValidation;
import com.dita.audit.model.ScoreBreakdown;
import com.dita.audit.model.VideoChecklist;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Converte o JSON de resposta da API em {@link AuditResult}.
 * Classe utilitária sem estado — todos os métodos são estáticos.
 */
class ResultParser {

    private static final String TAG = "ResultParser";

    private ResultParser() { }

    static AuditResult parse(String inspectionId, JSONObject json) {
        try {
            AuditStatus status = AuditStatus.fromApiValue(json.optString("auditStatus", "PROCESSING"));
            int score = json.optInt("score", 0);
            String summary = json.optString("summary", null);
            String webUrl = json.optString("webUrl", null);
            int totalDetections = json.optInt("totalDetections", 0);

            return new AuditResult.Builder()
                    .inspectionId(inspectionId)
                    .status(status)
                    .score(score)
                    .summary(summary)
                    .items(parseItems(json.optJSONArray("detections")))
                    .blockingReasons(parseStringArray(json.optJSONArray("blockingReasons")))
                    .scoreBreakdown(parseBreakdown(json.optJSONObject("scoreBreakdown")))
                    .coveredSides(parseStringArray(json.optJSONArray("coveredSides")))
                    .missingSides(parseStringArray(json.optJSONArray("missingSides")))
                    .webUrl(webUrl)
                    .totalDetections(totalDetections)
                    .fsmValidation(parseFsm(json.optJSONObject("fsmValidation")))
                    .videoChecklists(parseVideoChecklists(json.optJSONArray("videoChecklists")))
                    .build();
        } catch (Exception e) {
            Log.e(TAG, "Erro ao parsear resultado", e);
            return new AuditResult.Builder()
                    .inspectionId(inspectionId)
                    .status(AuditStatus.FAILED)
                    .score(0)
                    .build();
        }
    }

    // ─── Parsers internos ────────────────────────────────────────

    private static List<AuditItemDetail> parseItems(JSONArray arr) throws Exception {
        List<AuditItemDetail> items = new ArrayList<>();
        if (arr == null) return items;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject det = arr.getJSONObject(i);
            items.add(new AuditItemDetail(
                    det.optString("part", ""),
                    det.optBoolean("detected", false),
                    det.optDouble("confidence", 0),
                    det.optString("side", "")
            ));
        }
        return items;
    }

    private static ScoreBreakdown parseBreakdown(JSONObject sb) {
        if (sb == null) return null;
        return new ScoreBreakdown(
                sb.optInt("coverage360", 0),
                sb.optInt("criticalItems", 0),
                sb.optInt("checklistGeneral", 0),
                sb.optInt("avgConfidence", 0),
                sb.optInt("finalScore", 0)
        );
    }

    private static FsmValidation parseFsm(JSONObject fsm) {
        if (fsm == null) return null;
        try {
            boolean isValid = fsm.optBoolean("isValid", true);

            List<FsmValidation.Violation> violations = new ArrayList<>();
            JSONArray vArr = fsm.optJSONArray("violations");
            if (vArr != null) {
                for (int i = 0; i < vArr.length(); i++) {
                    JSONObject v = vArr.getJSONObject(i);
                    violations.add(new FsmValidation.Violation(
                            v.optString("type", ""),
                            v.optString("severity", "INFO"),
                            v.optString("message", "")
                    ));
                }
            }

            List<String> sideSequence = parseStringArray(fsm.optJSONArray("sideSequence"));
            int totalTransitions = fsm.optInt("totalTransitions", 0);
            int totalDurationMs = fsm.optInt("totalDurationMs", 0);

            Map<String, Integer> sideDurations = parseIntMap(fsm.optJSONObject("sideDurationsMs"));
            Map<String, Double> confPerSide = parseDoubleMap(fsm.optJSONObject("confidencePerSide"));

            return new FsmValidation(isValid, violations, sideSequence,
                    sideDurations, totalTransitions, totalDurationMs, confPerSide);
        } catch (Exception e) {
            Log.w(TAG, "Erro ao parsear FSM validation", e);
            return null;
        }
    }

    private static List<VideoChecklist> parseVideoChecklists(JSONArray arr) {
        List<VideoChecklist> checklists = new ArrayList<>();
        if (arr == null) return checklists;
        try {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject vc = arr.getJSONObject(i);
                int videoIndex = vc.optInt("videoIndex", i + 1);
                String videoType = vc.optString("videoType", "CLOSED");
                int score = vc.optInt("score", 0);
                int totalParts = vc.optInt("totalParts", 21);
                int detectedCount = vc.optInt("detectedCount", 0);

                List<VideoChecklist.PartDetection> parts = new ArrayList<>();
                JSONArray partsArr = vc.optJSONArray("parts");
                if (partsArr != null) {
                    for (int j = 0; j < partsArr.length(); j++) {
                        JSONObject p = partsArr.getJSONObject(j);
                        parts.add(new VideoChecklist.PartDetection(
                                p.optString("part", ""),
                                p.optString("displayName", ""),
                                p.optBoolean("detected", false),
                                p.optDouble("confidence", 0)
                        ));
                    }
                }

                checklists.add(new VideoChecklist(
                        videoIndex, videoType, score, totalParts, detectedCount, parts));
            }
        } catch (Exception e) {
            Log.w(TAG, "Erro ao parsear videoChecklists", e);
        }
        return checklists;
    }

    // ─── Utilitários ─────────────────────────────────────────────

    private static List<String> parseStringArray(JSONArray arr) {
        List<String> list = new ArrayList<>();
        if (arr == null) return list;
        for (int i = 0; i < arr.length(); i++) {
            list.add(arr.optString(i, ""));
        }
        return list;
    }

    private static Map<String, Integer> parseIntMap(JSONObject obj) {
        Map<String, Integer> map = new HashMap<>();
        if (obj == null) return map;
        java.util.Iterator<String> keys = obj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            map.put(key, obj.optInt(key, 0));
        }
        return map;
    }

    private static Map<String, Double> parseDoubleMap(JSONObject obj) {
        Map<String, Double> map = new HashMap<>();
        if (obj == null) return map;
        java.util.Iterator<String> keys = obj.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            map.put(key, obj.optDouble(key, 0));
        }
        return map;
    }
}
