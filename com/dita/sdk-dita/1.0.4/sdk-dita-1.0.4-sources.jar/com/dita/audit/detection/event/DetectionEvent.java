package com.dita.audit.detection.event;

import com.dita.audit.detection.Detection;
import com.dita.audit.detection.VehiclePart;

import java.util.List;

/**
 * Evento publicado pelo VehiclePartProcessor a cada frame processado.
 * Contém as detecções brutas (para overlay) e a lista de peças acumuladas.
 */
public class DetectionEvent {

    private final List<Detection> detections;
    private final List<VehiclePart> parts;
    private final int totalUniquePartsDetected;
    private final int sourceWidth;
    private final int sourceHeight;

    public DetectionEvent(List<Detection> detections, List<VehiclePart> parts,
                          int totalUniquePartsDetected, int sourceWidth, int sourceHeight) {
        this.detections = detections;
        this.parts = parts;
        this.totalUniquePartsDetected = totalUniquePartsDetected;
        this.sourceWidth = sourceWidth;
        this.sourceHeight = sourceHeight;
    }

    public List<Detection> getDetections() { return detections; }
    public List<VehiclePart> getParts() { return parts; }
    public int getTotalUniquePartsDetected() { return totalUniquePartsDetected; }
    public int getSourceWidth() { return sourceWidth; }
    public int getSourceHeight() { return sourceHeight; }
}
