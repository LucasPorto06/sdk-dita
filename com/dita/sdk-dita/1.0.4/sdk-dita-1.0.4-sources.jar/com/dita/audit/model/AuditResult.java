package com.dita.audit.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Resultado completo da auditoria.
 *
 * <p>Contém o veredicto (status), score composto, breakdown detalhado,
 * lista de peças detectadas, motivos de reprovação, cobertura 360° e
 * link para visualização detalhada no painel web.</p>
 */
public class AuditResult {

    private final String inspectionId;
    private final AuditStatus status;
    private final int score;
    private final String summary;
    private final List<AuditItemDetail> items;
    private final List<String> blockingReasons;
    private final ScoreBreakdown scoreBreakdown;
    private final List<String> coveredSides;
    private final List<String> missingSides;
    private final String webUrl;
    private final int totalDetections;
    private final FsmValidation fsmValidation;
    private final List<VideoChecklist> videoChecklists;

    private AuditResult(Builder builder) {
        this.inspectionId = builder.inspectionId;
        this.status = builder.status;
        this.score = builder.score;
        this.summary = builder.summary;
        this.items = builder.items != null ? builder.items : new ArrayList<>();
        this.blockingReasons = builder.blockingReasons != null ? builder.blockingReasons : new ArrayList<>();
        this.scoreBreakdown = builder.scoreBreakdown;
        this.coveredSides = builder.coveredSides != null ? builder.coveredSides : new ArrayList<>();
        this.missingSides = builder.missingSides != null ? builder.missingSides : new ArrayList<>();
        this.webUrl = builder.webUrl;
        this.totalDetections = builder.totalDetections;
        this.fsmValidation = builder.fsmValidation;
        this.videoChecklists = builder.videoChecklists != null ? builder.videoChecklists : new ArrayList<>();
    }

    /** ID único da inspeção */
    public String getInspectionId() { return inspectionId; }

    /** Status final: APPROVED, REJECTED, NEEDS_REVIEW, PROCESSING ou FAILED */
    public AuditStatus getStatus() { return status; }

    /** Score composto 0-100 */
    public int getScore() { return score; }

    /** Resumo legível da auditoria (ex: "Inspeção aprovada. Score: 89/100...") */
    public String getSummary() { return summary; }

    /** Lista de peças/itens detectados com confiança e lado */
    public List<AuditItemDetail> getItems() { return items; }

    /** Motivos de reprovação (vazio se aprovado) */
    public List<String> getBlockingReasons() { return blockingReasons; }

    /** Breakdown detalhado do score (cobertura, críticos, checklist, confiança) */
    public ScoreBreakdown getScoreBreakdown() { return scoreBreakdown; }

    /** Lados do veículo filmados (ex: ["dianteira", "traseira", "lateral_direita"]) */
    public List<String> getCoveredSides() { return coveredSides; }

    /** Lados do veículo que faltaram (ex: ["lateral_esquerda"]) */
    public List<String> getMissingSides() { return missingSides; }

    /** URL para ver resultado detalhado no painel web */
    public String getWebUrl() { return webUrl; }

    /** Total de peças detectadas pela IA */
    public int getTotalDetections() { return totalDetections; }

    /** Resultado da validação FSM anti-fraude (null se não disponível) */
    public FsmValidation getFsmValidation() { return fsmValidation; }

    /** Checklists de detecção por vídeo (V1, V2) */
    public List<VideoChecklist> getVideoChecklists() { return videoChecklists; }

    /** Atalho: FSM validou a sequência? */
    public boolean isFsmValid() { return fsmValidation == null || fsmValidation.isValid(); }

    /** Atalho: vistoria aprovada? */
    public boolean isApproved() { return status == AuditStatus.APPROVED; }

    /** Atalho: vistoria reprovada? */
    public boolean isRejected() { return status == AuditStatus.REJECTED; }

    /** Atalho: 360° completo? (nenhum lado faltante) */
    public boolean is360Complete() { return missingSides.isEmpty(); }

    /** Lista de itens que foram detectados (aprovados) */
    public List<AuditItemDetail> getApprovedItems() {
        List<AuditItemDetail> approved = new ArrayList<>();
        for (AuditItemDetail item : items) {
            if (item.isDetected()) approved.add(item);
        }
        return approved;
    }

    /** Lista de itens que NÃO foram detectados (reprovados) */
    public List<AuditItemDetail> getRejectedItems() {
        List<AuditItemDetail> rejected = new ArrayList<>();
        for (AuditItemDetail item : items) {
            if (!item.isDetected()) rejected.add(item);
        }
        return rejected;
    }

    @Override
    public String toString() {
        return "AuditResult{" +
                "inspectionId='" + inspectionId + '\'' +
                ", status=" + status.getLabel() +
                ", score=" + score +
                ", items=" + items.size() +
                ", coveredSides=" + coveredSides.size() + "/4" +
                ", blockingReasons=" + blockingReasons.size() +
                '}';
    }

    // ─── Builder ─────────────────────────────────────────────

    public static class Builder {
        private String inspectionId;
        private AuditStatus status = AuditStatus.PROCESSING;
        private int score;
        private String summary;
        private List<AuditItemDetail> items;
        private List<String> blockingReasons;
        private ScoreBreakdown scoreBreakdown;
        private List<String> coveredSides;
        private List<String> missingSides;
        private String webUrl;
        private int totalDetections;
        private FsmValidation fsmValidation;
        private List<VideoChecklist> videoChecklists;

        public Builder inspectionId(String id) { this.inspectionId = id; return this; }
        public Builder status(AuditStatus s) { this.status = s; return this; }
        public Builder score(int s) { this.score = s; return this; }
        public Builder summary(String s) { this.summary = s; return this; }
        public Builder items(List<AuditItemDetail> i) { this.items = i; return this; }
        public Builder blockingReasons(List<String> r) { this.blockingReasons = r; return this; }
        public Builder scoreBreakdown(ScoreBreakdown b) { this.scoreBreakdown = b; return this; }
        public Builder coveredSides(List<String> s) { this.coveredSides = s; return this; }
        public Builder missingSides(List<String> s) { this.missingSides = s; return this; }
        public Builder webUrl(String u) { this.webUrl = u; return this; }
        public Builder totalDetections(int t) { this.totalDetections = t; return this; }
        public Builder fsmValidation(FsmValidation f) { this.fsmValidation = f; return this; }
        public Builder videoChecklists(List<VideoChecklist> v) { this.videoChecklists = v; return this; }

        public AuditResult build() { return new AuditResult(this); }
    }
}
