package com.dita.audit;

/**
 * Configuração do SDK Dita.
 */
public class DitaConfig {

    private static final String BASE_URL = "https://dita.solutionsa.com.br";

    private final String apiKey;
    private final long pollingIntervalMs;
    private final long pollingTimeoutMs;
    private final boolean showResultScreen;

    private DitaConfig(Builder builder) {
        this.apiKey = builder.apiKey;
        this.pollingIntervalMs = builder.pollingIntervalMs;
        this.pollingTimeoutMs = builder.pollingTimeoutMs;
        this.showResultScreen = builder.showResultScreen;
    }

    public String getBaseUrl() { return BASE_URL; }
    public String getApiKey() { return apiKey; }
    public long getPollingIntervalMs() { return pollingIntervalMs; }
    public long getPollingTimeoutMs() { return pollingTimeoutMs; }
    public boolean isShowResultScreen() { return showResultScreen; }

    public String getApiBaseUrl() {
        return BASE_URL + "/api/v1";
    }

    public static class Builder {
        private String apiKey;
        private long pollingIntervalMs = 3000;
        private long pollingTimeoutMs = 300000;
        private boolean showResultScreen = false;

        public Builder apiKey(String apiKey) {
            this.apiKey = apiKey;
            return this;
        }

        public Builder pollingIntervalMs(long ms) {
            this.pollingIntervalMs = ms;
            return this;
        }

        public Builder pollingTimeoutMs(long ms) {
            this.pollingTimeoutMs = ms;
            return this;
        }

        public Builder showResultScreen(boolean show) {
            this.showResultScreen = show;
            return this;
        }

        public DitaConfig build() {
            return new DitaConfig(this);
        }
    }
}
