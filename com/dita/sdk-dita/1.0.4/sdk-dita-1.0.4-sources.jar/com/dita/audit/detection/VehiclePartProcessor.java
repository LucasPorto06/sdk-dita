package com.dita.audit.detection;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;

import com.dita.audit.detection.event.DetectionEvent;
import com.dita.audit.detection.event.NoDetectionTimeoutEvent;

import org.greenrobot.eventbus.EventBus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Processador de frames da câmera que roda YOLO em background.
 *
 * <p>Implementa {@link ImageAnalysis.Analyzer} — recebe frames do CameraX,
 * roda detecção via {@link YoloDetector}, acumula peças detectadas e
 * publica resultados via {@link EventBus}.</p>
 *
 * <p>A thread principal nunca é tocada aqui. Toda comunicação com a UI
 * é feita exclusivamente via EventBus.</p>
 */
public class VehiclePartProcessor implements ImageAnalysis.Analyzer {

    private static final String TAG = "VehiclePartProcessor";
    private static final long ANTI_FLICKER_MS = 400;
    private static final long NO_DETECTION_TIMEOUT_MS = 6000;
    private static final int MIN_VEHICLE_PARTS = 6;

    private final YoloDetector detector;
    private final AtomicBoolean isProcessing = new AtomicBoolean(false);

    // Peças acumuladas (thread-safe)
    private final ConcurrentHashMap<String, VehiclePart> partsMap = new ConcurrentHashMap<>();

    // Anti-flicker
    private volatile List<Detection> lastDetections = Collections.emptyList();
    private volatile long lastDetectionTimeMs = 0;

    // Estado
    private volatile boolean recording = false;
    private volatile boolean vehicleDetected = false;
    private volatile boolean timeoutFired = false;
    private int frameCount = 0;

    public VehiclePartProcessor(YoloDetector detector) {
        this.detector = detector;
    }

    // ─── ImageAnalysis.Analyzer ──────────────────────────────────

    @Override
    public void analyze(@NonNull ImageProxy image) {
        if (!detector.isReady() || isProcessing.getAndSet(true)) {
            image.close();
            return;
        }
        try {
            long t0 = System.currentTimeMillis();
            Bitmap bitmap = image.toBitmap();
            int srcW = bitmap.getWidth();
            int srcH = bitmap.getHeight();
            long t1 = System.currentTimeMillis();
            List<Detection> detections = detector.detect(bitmap);
            long t2 = System.currentTimeMillis();
            bitmap.recycle();

            List<Detection> display = applyAntiFlicker(detections);
            updateParts(detections);
            checkNoDetectionTimeout();

            int partsCount = partsMap.size();
            EventBus.getDefault().post(new DetectionEvent(
                    display,
                    partsCount > 0 ? new ArrayList<>(partsMap.values()) : Collections.emptyList(),
                    partsCount,
                    srcW, srcH
            ));
            long t3 = System.currentTimeMillis();

            if (frameCount++ % 30 == 0) {
                Log.d(TAG, "Pipeline: toBitmap=" + (t1 - t0) + "ms | detect=" + (t2 - t1) + "ms | total=" + (t3 - t0) + "ms");
            }
        } catch (Exception e) {
            Log.w(TAG, "Erro ao processar frame: " + e.getMessage());
        } finally {
            isProcessing.set(false);
            image.close();
        }
    }

    // ─── Anti-flicker ────────────────────────────────────────────

    private List<Detection> applyAntiFlicker(List<Detection> detections) {
        long now = System.currentTimeMillis();
        if (!detections.isEmpty()) {
            lastDetections = detections;
            lastDetectionTimeMs = now;
            return detections;
        }
        if (!lastDetections.isEmpty() && (now - lastDetectionTimeMs) < ANTI_FLICKER_MS) {
            return lastDetections;
        }
        lastDetections = Collections.emptyList();
        return lastDetections;
    }

    // ─── Acumular peças ──────────────────────────────────────────

    private void updateParts(List<Detection> detections) {
        long now = System.currentTimeMillis();
        for (Detection det : detections) {
            String label = det.getLabel();
            VehiclePart existing = partsMap.get(label);
            if (existing != null) {
                existing.update(det.getConfidence(), now);
            } else {
                partsMap.put(label, new VehiclePart(label, det.getConfidence(), now));
            }
        }

        if (!vehicleDetected && partsMap.size() >= MIN_VEHICLE_PARTS) {
            vehicleDetected = true;
            Log.i(TAG, "Veículo detectado: " + partsMap.size() + " peças");
        }
    }

    // ─── Timeout sem detecção ────────────────────────────────────

    private void checkNoDetectionTimeout() {
        if (!recording || timeoutFired) return;

        long now = System.currentTimeMillis();
        if (lastDetectionTimeMs > 0 && (now - lastDetectionTimeMs) > NO_DETECTION_TIMEOUT_MS) {
            timeoutFired = true;
            long silence = now - lastDetectionTimeMs;
            EventBus.getDefault().post(new NoDetectionTimeoutEvent(silence));
        }
    }

    // ─── Controle externo ────────────────────────────────────────

    /** Sinaliza início de gravação (ativa monitoramento de timeout) */
    public void onRecordingStarted() {
        recording = true;
        timeoutFired = false;
        lastDetectionTimeMs = System.currentTimeMillis();
    }

    /** Sinaliza fim de gravação */
    public void onRecordingStopped() {
        recording = false;
    }

    /** Retorna true se veículo foi detectado (>= MIN_VEHICLE_PARTS peças únicas) */
    public boolean isVehicleDetected() {
        return vehicleDetected;
    }

    /** Total de peças únicas detectadas */
    public int getUniquePartsCount() {
        return partsMap.size();
    }

    /** Retorna mapa de peças para build do payload */
    public ConcurrentHashMap<String, VehiclePart> getPartsMap() {
        return partsMap;
    }

    /** Reseta estado (entre tentativas) */
    public void reset() {
        partsMap.clear();
        vehicleDetected = false;
        timeoutFired = false;
        recording = false;
        lastDetections = Collections.emptyList();
        lastDetectionTimeMs = 0;
    }

    /** Libera recursos e para de postar eventos (chamado no onStop da Activity) */
    public void release() {
        recording = false;
        isProcessing.set(true); // bloqueia novos frames
        partsMap.clear();
        lastDetections = Collections.emptyList();
    }
}
