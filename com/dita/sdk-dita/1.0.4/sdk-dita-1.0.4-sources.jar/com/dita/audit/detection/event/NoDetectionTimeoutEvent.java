package com.dita.audit.detection.event;

/**
 * Evento publicado quando não há detecções por tempo prolongado durante gravação.
 * A Activity deve reagir parando a gravação e alertando o usuário.
 */
public class NoDetectionTimeoutEvent {

    private final long silenceDurationMs;

    public NoDetectionTimeoutEvent(long silenceDurationMs) {
        this.silenceDurationMs = silenceDurationMs;
    }

    public long getSilenceDurationMs() { return silenceDurationMs; }
}
