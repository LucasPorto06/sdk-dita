package com.dita.audit.detection;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

/**
 * View overlay que desenha bounding boxes das detecções YOLO sobre o preview da câmera.
 * Mostra diretamente o último resultado da inferência — sem efeitos ou persistência.
 */
public class DetectionOverlayView extends View {

    private List<Detection> detections = new ArrayList<>();
    private int sourceWidth = 0;
    private int sourceHeight = 0;
    private final BoxSmoother smoother = new BoxSmoother();

    private final Paint boxPaint = new Paint();
    private final Paint textPaint = new Paint();
    private final Paint bgPaint = new Paint();

    private static final int[] COLORS = {
            0xFF4CAF50, 0xFF2196F3, 0xFFFF9800, 0xFF9C27B0,
            0xFFE91E63, 0xFF00BCD4, 0xFFFFEB3B, 0xFF795548,
    };

    public DetectionOverlayView(Context context) {
        super(context);
        init();
    }

    public DetectionOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public DetectionOverlayView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setStrokeWidth(4f);
        boxPaint.setAntiAlias(true);

        textPaint.setColor(Color.WHITE);
        textPaint.setTextSize(32f);
        textPaint.setAntiAlias(true);
        textPaint.setFakeBoldText(true);
        textPaint.setShadowLayer(3f, 1f, 1f, Color.BLACK);

        bgPaint.setStyle(Paint.Style.FILL);
        bgPaint.setAntiAlias(true);
    }

    /**
     * Atualiza detecções e redesenha.
     * Se chamado da main thread (ex: EventBus MAIN), usa invalidate() direto.
     * Se chamado de outra thread, usa postInvalidate().
     */
    public void setDetections(List<Detection> newDetections, int srcW, int srcH) {
        List<Detection> brutas = newDetections != null ? newDetections : new ArrayList<>();
        this.detections = smoother.suavizar(brutas);
        this.sourceWidth = srcW;
        this.sourceHeight = srcH;
        requestRedraw();
    }

    public void clear() {
        this.detections = new ArrayList<>();
        smoother.limpar();
        requestRedraw();
    }

    private void requestRedraw() {
        if (android.os.Looper.myLooper() == android.os.Looper.getMainLooper()) {
            invalidate();
        } else {
            postInvalidate();
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int viewW = getWidth();
        int viewH = getHeight();
        if (viewW == 0 || viewH == 0) return;

        // Compensar crop do PreviewView FILL_CENTER:
        // A câmera envia frame com aspect ratio diferente da tela.
        // PreviewView escala e corta pra preencher. Precisamos aplicar
        // a mesma transformação nos bounding boxes.
        float offsetX = 0, offsetY = 0;
        float scaleW = viewW, scaleH = viewH;

        if (sourceWidth > 0 && sourceHeight > 0) {
            float imageAspect = (float) sourceWidth / sourceHeight;
            float viewAspect = (float) viewW / viewH;

            if (imageAspect > viewAspect) {
                // Imagem mais larga que a view → crop horizontal
                scaleH = viewH;
                scaleW = viewH * imageAspect;
                offsetX = (scaleW - viewW) / 2f;
            } else {
                // Imagem mais alta que a view → crop vertical
                scaleW = viewW;
                scaleH = viewW / imageAspect;
                offsetY = (scaleH - viewH) / 2f;
            }
        }

        for (Detection det : detections) {
            RectF box = det.getBoundingBox();
            int color = COLORS[det.getClassId() % COLORS.length];

            float left = box.left * scaleW - offsetX;
            float top = box.top * scaleH - offsetY;
            float right = box.right * scaleW - offsetX;
            float bottom = box.bottom * scaleH - offsetY;

            // Bounding box
            boxPaint.setColor(color);
            canvas.drawRect(left, top, right, bottom, boxPaint);

            // Label: "Farol 92%"
            String text = det.getDisplayName() + " " +
                    String.format("%.0f%%", det.getConfidence() * 100);

            float textW = textPaint.measureText(text);
            float textH = textPaint.getTextSize();
            float padding = 6f;

            float labelTop = Math.max(0, top - textH - padding * 2);

            bgPaint.setColor(color);
            bgPaint.setAlpha(200);
            canvas.drawRect(left, labelTop, left + textW + padding * 2,
                    labelTop + textH + padding * 2, bgPaint);

            canvas.drawText(text, left + padding, labelTop + textH + padding, textPaint);
        }
    }
}
