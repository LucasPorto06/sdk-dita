package com.dita.audit.detection;

/**
 * Representa uma peça do veículo rastreada pelo processador.
 * Acumula estatísticas ao longo dos frames: contagem, confiança máxima, timestamps.
 */
public class VehiclePart {

    private final String label;
    private int detectionCount;
    private float maxConfidence;
    private long firstDetectedAt;
    private long lastDetectedAt;

    public VehiclePart(String label, float confidence, long timestamp) {
        this.label = label;
        this.detectionCount = 1;
        this.maxConfidence = confidence;
        this.firstDetectedAt = timestamp;
        this.lastDetectedAt = timestamp;
    }

    /** Atualiza estatísticas com nova detecção */
    public void update(float confidence, long timestamp) {
        detectionCount++;
        if (confidence > maxConfidence) maxConfidence = confidence;
        lastDetectedAt = timestamp;
    }

    public String getLabel() { return label; }
    public int getDetectionCount() { return detectionCount; }
    public float getMaxConfidence() { return maxConfidence; }
    public long getFirstDetectedAt() { return firstDetectedAt; }
    public long getLastDetectedAt() { return lastDetectedAt; }

    /** Nome em pt-BR para exibição */
    public String getDisplayName() {
        return Detection.displayNameFor(label);
    }
}
