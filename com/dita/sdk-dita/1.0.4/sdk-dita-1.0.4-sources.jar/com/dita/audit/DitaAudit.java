package com.dita.audit;

import android.app.Activity;
import android.content.Intent;
import android.util.Log;

import com.dita.audit.callback.DitaCallback;
import com.dita.audit.callback.DitaError;
import com.dita.audit.internal.ApiClient;
import com.dita.audit.model.ErrorCode;
import com.dita.audit.ui.CaptureActivity;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Ponto de entrada principal do SDK Dita Auditoria.
 *
 * <h3>Uso básico:</h3>
 * <pre>{@code
 * // 1. Configurar o SDK (uma vez, ex: no Application.onCreate)
 * DitaAudit.init(new DitaConfig.Builder()
 *     .apiKey("sua-api-key")
 *     .build());
 *
 * // 2. Iniciar uma vistoria
 * DitaAudit.getInstance().startInspection(activity,
 *     new InspectionData.Builder()
 *         .plate("ABC1D23")
 *         .chassis("9BWZZZ377VT004251")
 *         .vehicle("Onix 2024")
 *         .store("Loja Centro")
 *         .inspector("João Silva")
 *         .build(),
 *     new DitaCallback() {
 *         @Override
 *         public void onResult(AuditResult result) {
 *             // result.getStatus()  → AuditStatus.APPROVED
 *             // result.getScore()   → 89
 *             // result.getItems()   → lista de itens detectados
 *         }
 *
 *         @Override
 *         public void onError(DitaError error) {
 *             // error.getCode()    → ErrorCode.UPLOAD_FAILED
 *             // error.getMessage() → "Falha no upload do vídeo"
 *         }
 *     });
 * }</pre>
 */
public class DitaAudit {

    private static final String TAG = "DitaAudit";
    private static volatile DitaAudit instance;

    private DitaConfig config;
    private ApiClient apiClient;
    private volatile DitaCallback currentCallback;
    private volatile String currentInspectionId;
    private final AtomicBoolean cancelled = new AtomicBoolean(false);
    private final ExecutorService executor = createExecutor();
    private boolean showDetectionOverlay = true;

    private DitaAudit() {}

    /**
     * Inicializa o SDK com a configuração fornecida.
     * Deve ser chamado uma vez antes de usar qualquer funcionalidade.
     *
     * @param config Configuração do SDK
     */
    public static void init(DitaConfig config) {
        if (config == null) {
            throw new IllegalArgumentException("DitaConfig não pode ser null");
        }
        getInstance().config = config;
        getInstance().apiClient = new ApiClient(config);
        Log.i(TAG, "SDK Dita inicializado");
    }

    /**
     * Retorna a instância singleton do SDK.
     */
    public static DitaAudit getInstance() {
        if (instance == null) {
            synchronized (DitaAudit.class) {
                if (instance == null) {
                    instance = new DitaAudit();
                }
            }
        }
        return instance;
    }

    /**
     * Inicia o fluxo completo de vistoria:
     * 1. Cria a inspeção na API
     * 2. Abre a câmera para gravação dos 2 vídeos
     * 3. Faz upload dos vídeos
     * 4. Submete para processamento
     * 5. Retorna o resultado via callback
     *
     * @param activity   Activity atual (para iniciar a CaptureActivity)
     * @param data       Dados da vistoria (placa, chassi, etc.)
     * @param callback   Callback para receber o resultado ou erro
     */
    public void startInspection(Activity activity, InspectionData data, DitaCallback callback) {
        if (config == null || apiClient == null) {
            callback.onError(new DitaError(ErrorCode.INVALID_CONFIG,
                    "SDK não inicializado. Chame DitaAudit.init() primeiro."));
            return;
        }

        this.currentCallback = callback;
        this.currentInspectionId = null;
        this.cancelled.set(false);
        callback.onProgress("CREATING_INSPECTION", 0);

        executor.execute(() -> {
            try {
                // Criar inspeção na API
                String inspectionId = apiClient.createInspection(
                        data.getPlate(),
                        data.getChassis(),
                        data.getVehicle(),
                        data.getStore(),
                        data.getInspector(),
                        data.getExtras()
                );

                this.currentInspectionId = inspectionId;
                Log.i(TAG, "Inspeção criada: " + inspectionId);

                // Abrir câmera
                activity.runOnUiThread(() -> {
                    callback.onProgress("RECORDING_VIDEO_1", -1);
                    Intent intent = new Intent(activity, CaptureActivity.class);
                    intent.putExtra(CaptureActivity.EXTRA_SHOW_OVERLAY, showDetectionOverlay);
                    activity.startActivity(intent);
                });

            } catch (Exception e) {
                Log.e(TAG, "Erro ao criar inspeção", e);
                activity.runOnUiThread(() ->
                        callback.onError(new DitaError(ErrorCode.INSPECTION_CREATE_FAILED,
                                "Erro ao criar inspeção: " + e.getMessage(), e)));
            }
        });
    }

    /**
     * Define se o overlay de detecção (bounding boxes) será exibido em tempo real na tela de captura.
     *
     * @param show true para exibir, false para ocultar
     */
    public void setShowDetectionOverlay(boolean show) {
        this.showDetectionOverlay = show;
    }

    /**
     * Retorna se o overlay de detecção está habilitado.
     */
    public boolean isShowDetectionOverlay() {
        return showDetectionOverlay;
    }

    // ─── Internal getters (usados pela CaptureActivity) ──────────────

    /** @hide */
    public DitaConfig getConfig() {
        return config;
    }

    /** @hide */
    public ApiClient getApiClient() {
        return apiClient;
    }

    /** @hide */
    public DitaCallback getCurrentCallback() {
        return currentCallback;
    }

    /** @hide */
    public boolean isCancelled() {
        return cancelled.get();
    }

    /**
     * Cancela a vistoria em andamento.
     * O upload/polling será interrompido na próxima verificação.
     */
    public void cancelInspection() {
        cancelled.set(true);
        Log.i(TAG, "Inspeção cancelada pelo app");
    }

    /** @hide */
    public String getCurrentInspectionId() {
        return currentInspectionId;
    }

    /** @hide */
    public ExecutorService getExecutor() {
        return executor;
    }

    /**
     * Verifica se o SDK foi inicializado.
     */
    public boolean isInitialized() {
        return config != null && apiClient != null;
    }

    /**
     * Libera recursos do SDK.
     * Chamar quando não for mais usar o SDK.
     */
    public void shutdown() {
        if (apiClient != null) {
            apiClient.shutdown();
        }
        executor.shutdown();
        currentCallback = null;
        currentInspectionId = null;
        cancelled.set(false);
    }

    /**
     * Cria executor com thread nomeada que morre após 30s sem trabalho.
     * Core pool 0 + max 1 = no máximo 1 thread, que é liberada quando ociosa.
     */
    private static ExecutorService createExecutor() {
        ThreadFactory factory = r -> {
            Thread t = new Thread(r, "DitaSDK-Worker");
            t.setDaemon(true);
            t.setPriority(Thread.NORM_PRIORITY - 1);
            return t;
        };
        ThreadPoolExecutor pool = new ThreadPoolExecutor(
                0, 1,                    // 0 core, max 1 thread (tarefas sequenciais)
                30L, TimeUnit.SECONDS,   // morre após 30s ociosa
                new LinkedBlockingQueue<>(),
                factory
        );
        pool.allowCoreThreadTimeOut(true);
        return pool;
    }
}
