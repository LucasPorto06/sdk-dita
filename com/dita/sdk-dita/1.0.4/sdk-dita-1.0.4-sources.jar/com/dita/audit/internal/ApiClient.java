package com.dita.audit.internal;

import android.util.Log;

import com.dita.audit.DitaConfig;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Cliente HTTP interno para comunicação com a API do Dita Auditoria.
 * Classe interna — não exposta ao consumidor.
 */
public class ApiClient {

    private static final String TAG = "DitaApiClient";
    private static final MediaType JSON_TYPE = MediaType.parse("application/json; charset=utf-8");

    private final DitaConfig config;
    private final OkHttpClient httpClient;

    public ApiClient(DitaConfig config) {
        this.config = config;
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(120, TimeUnit.SECONDS)
                .build();
    }

    /**
     * Cria uma inspeção na API.
     * @return inspectionId gerado pelo servidor
     */
    public String createInspection(String plate, String chassis, String vehicle,
                                   String store, String inspector,
                                   Map<String, String> extras) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("plate", plate);
            body.put("chassis", chassis);
            if (vehicle != null) body.put("vehicle", vehicle);
            if (store != null) body.put("store", store);
            if (inspector != null) body.put("inspector", inspector);
            if (extras != null && !extras.isEmpty()) {
                JSONObject extrasJson = new JSONObject();
                for (Map.Entry<String, String> entry : extras.entrySet()) {
                    extrasJson.put(entry.getKey(), entry.getValue());
                }
                body.put("extras", extrasJson);
            }
        } catch (Exception e) {
            throw new IOException("Erro ao montar payload", e);
        }

        String url = config.getApiBaseUrl() + "/inspections";
        Request request = buildRequest(url, body.toString());

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "createInspection response: " + response.code() + " " + responseBody);

            if (!response.isSuccessful()) {
                throw new IOException("Erro ao criar inspeção: HTTP " + response.code() + " " + responseBody);
            }

            JSONObject json = new JSONObject(responseBody);
            return json.getString("inspectionId");
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Erro ao processar resposta", e);
        }
    }

    /**
     * Solicita URL assinada para upload de vídeo.
     * @return String[] { uploadUrl, storageKey }
     */
    public String[] getUploadUrl(String inspectionId, int videoIndex, long sizeBytes) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("contentType", "video/mp4");
            body.put("sizeBytes", sizeBytes);
        } catch (Exception e) {
            throw new IOException("Erro ao montar payload", e);
        }

        String url = config.getApiBaseUrl() + "/inspections/" + inspectionId + "/videos/" + videoIndex + "/upload-url";
        Request request = buildRequest(url, body.toString());

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "getUploadUrl response: " + response.code());

            if (!response.isSuccessful()) {
                throw new IOException("Erro ao obter URL de upload: HTTP " + response.code() + " " + responseBody);
            }

            JSONObject json = new JSONObject(responseBody);
            return new String[]{
                    json.getString("uploadUrl"),
                    json.getString("storageKey")
            };
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Erro ao processar resposta", e);
        }
    }

    /**
     * Faz upload do vídeo diretamente para o GCS via signed URL.
     * Inclui retry automático com backoff exponencial (até 3 tentativas).
     */
    public void uploadVideoToGcs(String signedUrl, File videoFile) throws IOException {
        executeWithRetry(3, "upload GCS", () -> {
            RequestBody fileBody = RequestBody.create(videoFile, MediaType.parse("video/mp4"));

            Request request = new Request.Builder()
                    .url(signedUrl)
                    .put(fileBody)
                    .addHeader("Content-Type", "video/mp4")
                    .build();

            try (Response response = httpClient.newCall(request).execute()) {
                String body = response.body() != null ? response.body().string() : "";
                Log.d(TAG, "uploadVideoToGcs response: " + response.code()
                        + " size=" + body.length());
                if (!response.isSuccessful()) {
                    throw new IOException("Erro no upload GCS: HTTP " + response.code()
                            + " " + body.substring(0, Math.min(body.length(), 200)));
                }
            }
        });
    }

    /**
     * Executa uma operação com retry e backoff exponencial.
     *
     * @param maxAttempts Número máximo de tentativas
     * @param operationName Nome da operação (para logs)
     * @param operation Operação a executar
     */
    private void executeWithRetry(int maxAttempts, String operationName,
                                  RetryableOperation operation) throws IOException {
        IOException lastException = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                operation.execute();
                return; // sucesso
            } catch (IOException e) {
                lastException = e;
                if (attempt < maxAttempts) {
                    long delayMs = (long) (1000 * Math.pow(2, attempt - 1)); // 1s, 2s, 4s
                    Log.w(TAG, operationName + " falhou (tentativa " + attempt + "/" + maxAttempts
                            + "), retentando em " + delayMs + "ms: " + e.getMessage());
                    try {
                        Thread.sleep(delayMs);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        throw new IOException("Retry interrompido", ie);
                    }
                }
            }
        }
        throw new IOException(operationName + " falhou após " + maxAttempts + " tentativas",
                lastException);
    }

    @FunctionalInterface
    private interface RetryableOperation {
        void execute() throws IOException;
    }

    /**
     * Confirma que o upload de um vídeo foi concluído.
     */
    public void confirmUpload(String inspectionId, int videoIndex, String storageKey,
                              long durationMs, String videoType) throws IOException {
        JSONObject body = new JSONObject();
        try {
            body.put("storageKey", storageKey);
            body.put("durationMs", durationMs);
            body.put("type", videoType);
        } catch (Exception e) {
            throw new IOException("Erro ao montar payload", e);
        }

        String url = config.getApiBaseUrl() + "/inspections/" + inspectionId
                + "/videos/" + videoIndex + "/upload-complete";
        Request request = buildRequest(url, body.toString());

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "confirmUpload response: " + response.code() + " " + responseBody);

            if (!response.isSuccessful()) {
                throw new IOException("Erro ao confirmar upload: HTTP " + response.code() + " " + responseBody);
            }
        }
    }

    /**
     * Submete a inspeção para processamento pela IA.
     */
    public void submitInspection(String inspectionId) throws IOException {
        String url = config.getApiBaseUrl() + "/inspections/" + inspectionId + "/submit";
        Request request = buildRequest(url, "{}");

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";
            Log.d(TAG, "submitInspection response: " + response.code() + " " + responseBody);

            if (!response.isSuccessful()) {
                throw new IOException("Erro ao submeter inspeção: HTTP " + response.code());
            }
        }
    }

    /**
     * Consulta o status da inspeção.
     * @return JSONObject com processStatus, auditStatus, score, etc.
     */
    public JSONObject getInspectionStatus(String inspectionId) throws IOException {
        String url = config.getApiBaseUrl() + "/inspections/" + inspectionId;

        Request.Builder builder = new Request.Builder().url(url).get();
        if (config.getApiKey() != null && !config.getApiKey().isEmpty()) {
            builder.addHeader("Authorization", "Bearer " + config.getApiKey());
        }
        Request request = builder.build();

        try (Response response = httpClient.newCall(request).execute()) {
            String responseBody = response.body() != null ? response.body().string() : "";

            if (!response.isSuccessful()) {
                throw new IOException("Erro ao consultar status: HTTP " + response.code());
            }

            return new JSONObject(responseBody);
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Erro ao processar resposta", e);
        }
    }

    /**
     * Envia as detecções YOLO on-device para o servidor.
     * Chamado após a gravação, antes do upload dos vídeos.
     */
    public void sendSdkDetections(String inspectionId, JSONObject detectionsPayload) {
        try {
            String url = config.getApiBaseUrl() + "/inspections/" + inspectionId + "/sdk-detections";
            Request request = buildRequest(url, detectionsPayload.toString());

            try (Response response = httpClient.newCall(request).execute()) {
                String responseBody = response.body() != null ? response.body().string() : "";
                Log.d(TAG, "sendSdkDetections response: " + response.code() + " " + responseBody);
            }
        } catch (Exception e) {
            Log.w(TAG, "Erro ao enviar detecções SDK (best-effort): " + e.getMessage());
        }
    }

    private Request buildRequest(String url, String jsonBody) {
        Request.Builder builder = new Request.Builder()
                .url(url)
                .post(RequestBody.create(jsonBody, JSON_TYPE));

        if (config.getApiKey() != null && !config.getApiKey().isEmpty()) {
            builder.addHeader("Authorization", "Bearer " + config.getApiKey());
        }

        return builder.build();
    }

    /**
     * Cancela/abandona uma inspeção no servidor.
     * Chamado quando o usuário sai sem completar.
     */
    public void cancelInspection(String inspectionId, String reason) {
        try {
            JSONObject body = new JSONObject();
            body.put("reason", reason);

            String url = config.getApiBaseUrl() + "/inspections/" + inspectionId + "/cancel-sdk";
            Request request = buildRequest(url, body.toString());

            // Client com timeout agressivo — precisa completar antes do processo morrer
            OkHttpClient fastClient = new OkHttpClient.Builder()
                    .connectTimeout(2, TimeUnit.SECONDS)
                    .writeTimeout(2, TimeUnit.SECONDS)
                    .readTimeout(2, TimeUnit.SECONDS)
                    .build();

            try (Response response = fastClient.newCall(request).execute()) {
                String responseBody = response.body() != null ? response.body().string() : "";
                Log.d(TAG, "cancelInspection response: " + response.code() + " " + responseBody);
            }
        } catch (Exception e) {
            Log.w(TAG, "Erro ao cancelar inspeção (best-effort): " + e.getMessage());
        }
    }

    public void shutdown() {
        httpClient.dispatcher().executorService().shutdown();
        httpClient.connectionPool().evictAll();
    }
}
