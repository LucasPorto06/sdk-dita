package com.dita.audit.model;

/**
 * Códigos de erro do SDK.
 * Cada valor contém uma chave numérica (key) e descrição legível (label).
 */
public enum ErrorCode {

    UNKNOWN(0, "Erro desconhecido"),
    NETWORK_ERROR(1, "Erro de conexão com o servidor"),
    CAMERA_ERROR(2, "Erro ao acessar a câmera"),
    CAMERA_PERMISSION_DENIED(3, "Permissão de câmera negada"),
    RECORDING_ERROR(4, "Erro durante a gravação"),
    UPLOAD_FAILED(5, "Falha no upload do vídeo"),
    INSPECTION_CREATE_FAILED(6, "Falha ao criar inspeção"),
    SUBMIT_FAILED(7, "Falha ao submeter inspeção"),
    POLLING_TIMEOUT(8, "Tempo limite de espera pelo resultado"),
    INVALID_CONFIG(9, "Configuração inválida do SDK"),
    INSPECTION_NOT_FOUND(10, "Inspeção não encontrada"),
    CANCELLED(11, "Operação cancelada pelo usuário"),
    VEHICLE_NOT_DETECTED(12, "Veículo não identificado nos vídeos");

    private final int key;
    private final String label;

    ErrorCode(int key, String label) {
        this.key = key;
        this.label = label;
    }

    public int getKey() {
        return key;
    }

    public String getLabel() {
        return label;
    }
}
