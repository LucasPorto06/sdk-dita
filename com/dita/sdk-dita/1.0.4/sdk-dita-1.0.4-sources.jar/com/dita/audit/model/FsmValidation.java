package com.dita.audit.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Resultado da validação do Autômato Finito Determinístico (AFD) anti-fraude.
 *
 * <p>O servidor valida que a sequência de captura dos vídeos segue um padrão
 * legítimo: todos os lados filmados, duração mínima por lado, sem edições
 * suspeitas, confiança adequada.</p>
 */
public class FsmValidation {

    private final boolean valid;
    private final List<Violation> violations;
    private final List<String> sideSequence;
    private final Map<String, Integer> sideDurationsMs;
    private final int totalTransitions;
    private final int totalDurationMs;
    private final Map<String, Double> confidencePerSide;

    public FsmValidation(boolean valid, List<Violation> violations,
                         List<String> sideSequence, Map<String, Integer> sideDurationsMs,
                         int totalTransitions, int totalDurationMs,
                         Map<String, Double> confidencePerSide) {
        this.valid = valid;
        this.violations = violations != null ? violations : new ArrayList<>();
        this.sideSequence = sideSequence != null ? sideSequence : new ArrayList<>();
        this.sideDurationsMs = sideDurationsMs != null ? sideDurationsMs : new HashMap<>();
        this.totalTransitions = totalTransitions;
        this.totalDurationMs = totalDurationMs;
        this.confidencePerSide = confidencePerSide != null ? confidencePerSide : new HashMap<>();
    }

    /** Validação passou? (sem violações BLOCKING) */
    public boolean isValid() { return valid; }

    /** Lista de violações detectadas */
    public List<Violation> getViolations() { return violations; }

    /** Tem violações bloqueantes? */
    public boolean hasBlockingViolations() {
        for (Violation v : violations) {
            if ("BLOCKING".equals(v.getSeverity())) return true;
        }
        return false;
    }

    /** Tem alertas (não bloqueantes)? */
    public boolean hasWarnings() {
        for (Violation v : violations) {
            if ("WARNING".equals(v.getSeverity())) return true;
        }
        return false;
    }

    /** Sequência de lados detectados nos frames (ex: [dianteira, lateral_direita, traseira, lateral_esquerda]) */
    public List<String> getSideSequence() { return sideSequence; }

    /** Duração em ms que cada lado foi filmado */
    public Map<String, Integer> getSideDurationsMs() { return sideDurationsMs; }

    /** Número de transições entre lados */
    public int getTotalTransitions() { return totalTransitions; }

    /** Duração total dos vídeos em ms */
    public int getTotalDurationMs() { return totalDurationMs; }

    /** Confiança média por lado (0.0-1.0) */
    public Map<String, Double> getConfidencePerSide() { return confidencePerSide; }

    @Override
    public String toString() {
        return "FsmValidation{valid=" + valid +
                ", violations=" + violations.size() +
                ", sequence=" + sideSequence +
                ", duration=" + totalDurationMs + "ms}";
    }

    // ─── Violation ──────────────────────────────────────────────

    public static class Violation {
        private final String type;
        private final String severity;
        private final String message;

        public Violation(String type, String severity, String message) {
            this.type = type;
            this.severity = severity;
            this.message = message;
        }

        /** Tipo: MISSING_SIDE, INSUFFICIENT_DURATION, EXCESSIVE_TRANSITIONS, etc. */
        public String getType() { return type; }

        /** Severidade: BLOCKING, WARNING, INFO */
        public String getSeverity() { return severity; }

        /** Mensagem legível */
        public String getMessage() { return message; }

        @Override
        public String toString() {
            return "[" + severity + "] " + type + ": " + message;
        }
    }
}
