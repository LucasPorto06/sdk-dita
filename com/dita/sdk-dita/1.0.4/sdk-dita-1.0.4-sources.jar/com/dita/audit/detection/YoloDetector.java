package com.dita.audit.detection;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.Log;

import org.tensorflow.lite.Interpreter;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;

/**
 * Detector YOLO on-device usando TensorFlow Lite.
 * Auto-detecta o formato de output do modelo (YOLO26, YOLOv8, etc).
 */
public class YoloDetector {

    private static final String TAG = "YoloDetector";
    private static final String MODEL_FILE = "yolo_detect_int8.tflite";
    private static final int INPUT_SIZE = 640;
    private static final float CONFIDENCE_THRESHOLD = 0.45f;
    private static final int NUM_CLASSES = 21;

    private Interpreter interpreter;
    private boolean isReady = false;
    // Buffers reutilizáveis (evita alocação + GC a cada frame)
    private ByteBuffer inputBuffer;
    private int[] pixelBuffer;
    private Bitmap reusableScaledBitmap;
    private Canvas reusableCanvas;
    private final Rect scaledRect = new Rect(0, 0, INPUT_SIZE, INPUT_SIZE);
    private java.util.Map<Integer, Object> reusableOutputMap;
    private float[][][] reusableDetOutput;

    // Formato de output detectado automaticamente
    private int numOutputs = 0;
    private int[][] outputShapes;
    private int detOutputIdx = -1;
    private int numDetections = 0;
    private int detSize = 0;
    private boolean transposed = false;

    public void initialize(Context context) {
        try {
            MappedByteBuffer model = loadModelFile(context);

            interpreter = createInterpreter(model);

            numOutputs = interpreter.getOutputTensorCount();
            outputShapes = new int[numOutputs][];
            for (int i = 0; i < numOutputs; i++) {
                outputShapes[i] = interpreter.getOutputTensor(i).shape();
            }

            // Auto-detect: encontrar o tensor de detecções
            detectOutputFormat();

            // Pré-alocar buffers reutilizáveis
            inputBuffer = ByteBuffer.allocateDirect(INPUT_SIZE * INPUT_SIZE * 3 * 4);
            inputBuffer.order(ByteOrder.nativeOrder());
            pixelBuffer = new int[INPUT_SIZE * INPUT_SIZE];

            reusableOutputMap = new java.util.HashMap<>();
            for (int i = 0; i < numOutputs; i++) {
                int[] shape = outputShapes[i];
                if (shape.length == 3) {
                    float[][][] buf = new float[shape[0]][shape[1]][shape[2]];
                    reusableOutputMap.put(i, buf);
                    if (i == detOutputIdx) reusableDetOutput = buf;
                } else if (shape.length == 4) {
                    reusableOutputMap.put(i, new float[shape[0]][shape[1]][shape[2]][shape[3]]);
                } else if (shape.length == 2) {
                    reusableOutputMap.put(i, new float[shape[0]][shape[1]]);
                }
            }

            Log.i(TAG, "YOLO pronto — dets=" + numDetections + " transposed=" + transposed);

            isReady = true;
        } catch (Exception e) {
            Log.e(TAG, "Erro ao carregar modelo YOLO", e);
            isReady = false;
        }
    }

    /**
     * Detecta qual output contém as detecções e seu formato.
     *
     * Formatos possíveis:
     *  - YOLO26 e2e:       [1, 300, 6]   → 300 dets, (x1,y1,x2,y2,conf,cls)
     *  - YOLO26-seg e2e:   [1, 300, 38]  → 300 dets, (x1,y1,x2,y2,conf,cls,32masks)
     *  - YOLO one-to-many: [1, 25, 8400] → transposto, (4bbox + 21cls = 25) x 8400
     *  - YOLOv8-seg o2m:   [1, 57, 8400] → transposto, (4 + 21 + 32 = 57) x 8400
     */
    private void detectOutputFormat() {
        for (int i = 0; i < numOutputs; i++) {
            int[] shape = outputShapes[i];
            if (shape.length != 3) continue;

            int dim1 = shape[1];
            int dim2 = shape[2];

            // Formato end-to-end: [1, N, 6] ou [1, N, 38] (N <= 300)
            if (dim2 >= 4 && dim2 <= 100 && dim1 > dim2) {
                detOutputIdx = i;
                numDetections = dim1;
                detSize = dim2;
                transposed = false;
                return;
            }

            // Formato transposto one-to-many: [1, attrs, 8400]
            if (dim1 < dim2 && dim2 > 100) {
                detOutputIdx = i;
                numDetections = dim2;
                detSize = dim1;
                transposed = true;
                return;
            }

            // Formato normal one-to-many: [1, 8400, attrs]
            if (dim1 > 100 && dim2 >= 4 && dim2 <= 100) {
                detOutputIdx = i;
                numDetections = dim1;
                detSize = dim2;
                transposed = false;
                return;
            }
        }

        // Fallback: usar primeiro output 3D encontrado
        for (int i = 0; i < numOutputs; i++) {
            if (outputShapes[i].length == 3) {
                detOutputIdx = i;
                numDetections = outputShapes[i][1];
                detSize = outputShapes[i][2];
                transposed = false;
                Log.w(TAG, "Formato de output não reconhecido — usando fallback output[" + i + "]");
                return;
            }
        }
    }

    public List<Detection> detect(Bitmap bitmap) {
        List<Detection> results = new ArrayList<>();
        if (!isReady || interpreter == null || bitmap == null || detOutputIdx < 0) return results;

        // Redimensionar para 640x640 (reutiliza bitmap + canvas pré-alocados)
        if (reusableScaledBitmap == null) {
            reusableScaledBitmap = Bitmap.createBitmap(INPUT_SIZE, INPUT_SIZE, Bitmap.Config.ARGB_8888);
            reusableCanvas = new Canvas(reusableScaledBitmap);
        }
        reusableCanvas.drawBitmap(bitmap, null, scaledRect, null);

        inputBuffer.rewind();
        reusableScaledBitmap.getPixels(pixelBuffer, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE);
        for (int pixel : pixelBuffer) {
            inputBuffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            inputBuffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            inputBuffer.putFloat((pixel & 0xFF) / 255.0f);
        }
        inputBuffer.rewind();

        // Inferência (reutiliza output buffers)
        try {
            interpreter.runForMultipleInputsOutputs(new Object[]{inputBuffer}, reusableOutputMap);
        } catch (Exception e) {
            Log.e(TAG, "Erro na inferência YOLO", e);
            return results;
        }

        // Parsear detecções
        if (detSize >= 5 && detSize <= 6 && !transposed) {
            results = parseE2E(reusableDetOutput);
        } else if (transposed) {
            results = parseTransposed(reusableDetOutput);
        } else if (detSize > 6) {
            results = parseE2E(reusableDetOutput);
        }

        // NMS por classe — remove boxes duplicados do mesmo objeto
        return aplicarNMS(results, 0.5f);
    }

    /** Parsear formato end-to-end: cada linha é [x1, y1, x2, y2, conf, cls, ...] */
    private List<Detection> parseE2E(float[][][] output) {
        List<Detection> results = new ArrayList<>();
        for (int i = 0; i < output[0].length; i++) {
            float[] row = output[0][i];
            float conf = row[4];
            if (conf < CONFIDENCE_THRESHOLD) continue;

            int cls = Math.round(row[5]);
            if (cls < 0 || cls >= NUM_CLASSES) continue;

            float x1 = clamp01(row[0]);
            float y1 = clamp01(row[1]);
            float x2 = clamp01(row[2]);
            float y2 = clamp01(row[3]);

            if (x2 - x1 < 0.01f || y2 - y1 < 0.01f) continue;

            results.add(new Detection(cls, Detection.labelFor(cls),
                    conf, new RectF(x1, y1, x2, y2)));
        }
        return results;
    }

    /** Parsear formato one-to-many transposto: [1, attrs, N] onde attrs = 4 + numClasses */
    private List<Detection> parseTransposed(float[][][] output) {
        List<Detection> results = new ArrayList<>();
        int attrs = output[0].length;
        int n = output[0][0].length;
        int classStart = 4; // após cx, cy, w, h

        for (int i = 0; i < n; i++) {
            // cx, cy, w, h
            float cx = output[0][0][i];
            float cy = output[0][1][i];
            float w = output[0][2][i];
            float h = output[0][3][i];

            // Encontrar classe com maior confiança
            float maxConf = 0;
            int bestClass = -1;
            int classEnd = Math.min(classStart + NUM_CLASSES, attrs);
            for (int c = classStart; c < classEnd; c++) {
                if (output[0][c][i] > maxConf) {
                    maxConf = output[0][c][i];
                    bestClass = c - classStart;
                }
            }

            if (maxConf < CONFIDENCE_THRESHOLD) continue;
            if (bestClass < 0 || bestClass >= NUM_CLASSES) continue;

            // xywh → xyxy (pixel space → proporção)
            float x1 = clamp01((cx - w / 2) / INPUT_SIZE);
            float y1 = clamp01((cy - h / 2) / INPUT_SIZE);
            float x2 = clamp01((cx + w / 2) / INPUT_SIZE);
            float y2 = clamp01((cy + h / 2) / INPUT_SIZE);

            if (x2 - x1 < 0.01f || y2 - y1 < 0.01f) continue;

            results.add(new Detection(bestClass, Detection.labelFor(bestClass),
                    maxConf, new RectF(x1, y1, x2, y2)));
        }
        return results;
    }

    /**
     * Non-Maximum Suppression por classe.
     * Remove detecções sobrepostas mantendo a de maior confiança.
     */
    private List<Detection> aplicarNMS(List<Detection> deteccoes, float iouThreshold) {
        if (deteccoes.size() <= 1) return deteccoes;

        // Ordenar por confiança (maior primeiro)
        java.util.Collections.sort(deteccoes, (a, b) ->
                Float.compare(b.getConfidence(), a.getConfidence()));

        List<Detection> resultado = new ArrayList<>();
        boolean[] suprimido = new boolean[deteccoes.size()];

        for (int i = 0; i < deteccoes.size(); i++) {
            if (suprimido[i]) continue;
            Detection atual = deteccoes.get(i);
            resultado.add(atual);

            for (int j = i + 1; j < deteccoes.size(); j++) {
                if (suprimido[j]) continue;
                Detection outro = deteccoes.get(j);

                // Só suprime se for mesma classe
                if (atual.getClassId() != outro.getClassId()) continue;

                if (calcularIoU(atual.getBoundingBox(), outro.getBoundingBox()) > iouThreshold) {
                    suprimido[j] = true;
                }
            }
        }
        return resultado;
    }

    /** Calcula IoU entre dois RectF */
    private float calcularIoU(RectF a, RectF b) {
        float interLeft = Math.max(a.left, b.left);
        float interTop = Math.max(a.top, b.top);
        float interRight = Math.min(a.right, b.right);
        float interBottom = Math.min(a.bottom, b.bottom);

        float interArea = Math.max(0, interRight - interLeft) * Math.max(0, interBottom - interTop);
        if (interArea == 0) return 0;

        float areaA = (a.right - a.left) * (a.bottom - a.top);
        float areaB = (b.right - b.left) * (b.bottom - b.top);
        float unionArea = areaA + areaB - interArea;

        return unionArea > 0 ? interArea / unionArea : 0;
    }

    private float clamp01(float v) {
        return Math.max(0, Math.min(1, v));
    }

    public boolean isReady() { return isReady; }

    public void close() {
        if (interpreter != null) {
            interpreter.close();
            interpreter = null;
        }
        if (reusableScaledBitmap != null) {
            reusableScaledBitmap.recycle();
            reusableScaledBitmap = null;
        }
        isReady = false;
    }

    /**
     * Cria Interpreter otimizado pra modelo INT8.
     * CPU + XNNPACK com 4 threads — melhor performance pra INT8 quantizado.
     */
    private Interpreter createInterpreter(MappedByteBuffer model) {
        Interpreter.Options opts = new Interpreter.Options();
        opts.setNumThreads(4);
        Log.i(TAG, "CPU (4 threads + XNNPACK) ativado");
        return new Interpreter(model, opts);
    }

    private MappedByteBuffer loadModelFile(Context context) throws IOException {
        android.content.res.AssetFileDescriptor afd =
                context.getAssets().openFd(MODEL_FILE);
        FileInputStream fis = new FileInputStream(afd.getFileDescriptor());
        FileChannel channel = fis.getChannel();
        long startOffset = afd.getStartOffset();
        long declaredLength = afd.getDeclaredLength();
        MappedByteBuffer buffer = channel.map(FileChannel.MapMode.READ_ONLY,
                startOffset, declaredLength);
        fis.close();
        afd.close();
        return buffer;
    }
}
