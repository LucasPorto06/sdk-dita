package com.dita.audit.ui;

import android.Manifest;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Size;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.video.FileOutputOptions;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.CameraController;
import androidx.camera.view.LifecycleCameraController;
import androidx.camera.view.PreviewView;
import androidx.camera.view.video.AudioConfig;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.dita.audit.DitaAudit;
import com.dita.audit.R;
import com.dita.audit.callback.DitaCallback;
import com.dita.audit.callback.DitaError;
import com.dita.audit.detection.DetectionOverlayView;
import com.dita.audit.detection.VehiclePartProcessor;
import com.dita.audit.detection.YoloDetector;
import com.dita.audit.detection.event.DetectionEvent;
import com.dita.audit.detection.event.NoDetectionTimeoutEvent;
import com.dita.audit.model.ErrorCode;


import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.io.File;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Activity de captura de vídeos da vistoria.
 *
 * <p>Responsabilidades da Activity (main thread):
 * abrir câmera, pintar overlay, gerenciar UI de gravação.</p>
 *
 * <p>Processamento pesado (YOLO, stats) fica no {@link VehiclePartProcessor}
 * que roda em background e comunica via {@link EventBus}.</p>
 */
public class CaptureActivity extends AppCompatActivity {

    private static final String TAG = "DitaCaptureActivity";
    private static final int REQUEST_CAMERA_PERMISSION = 1001;
    public static final String EXTRA_SHOW_OVERLAY = "dita_show_overlay";

    /** Etapa atual da vistoria */
    private enum Step { VIDEO_1, VIDEO_2 }

    // ─── Views ───────────────────────────────────────────────────
    private PreviewView previewView;
    private ImageButton btnRecord;
    private ImageButton btnClose;
    private TextView tvStepTitle, tvStepDescription, tvTimer, tvRecordHint;
    private TextView tvProcessingStatus;
    private View stepDot1, stepDot2;
    private View overlayProcessing;
    private ProgressBar progressBar, progressBarHorizontal;
    private TextView tvCountdown;
    private DetectionOverlayView detectionOverlay;

    // Resultado
    private View overlayResultado;
    private TextView tvResultScore, tvResultStatus, tvResultResumo;
    private LinearLayout layoutVideoChecklists;
    private com.dita.audit.model.AuditResult ultimoResultado;

    // Roteiro
    private View painelRoteiro;
    private TextView tvLadoAtual, tvInstrucaoLado, tvProgressoRoteiro;
    private LinearLayout layoutChecklist;
    private CaptureGuide captureGuide;

    // ─── Câmera e gravação ───────────────────────────────────────
    private LifecycleCameraController cameraController;
    private Recording activeRecording;
    private boolean isRecording = false;

    // ─── Estado ──────────────────────────────────────────────────
    private Step currentStep = Step.VIDEO_1;
    private File video1File;
    private File video2File;
    private long recordingStartTime;
    private volatile boolean inspectionCompleted = false;
    private boolean cancelledByTimeout = false;
    private boolean showOverlay = true;

    // ─── Background ──────────────────────────────────────────────
    private final ExecutorService analysisExecutor = Executors.newSingleThreadExecutor();
    private ExecutorService executor;
    private YoloDetector yoloDetector;
    private VehiclePartProcessor processor;

    // ─── Timer ───────────────────────────────────────────────────
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    // ═══════════════════════════════════════════════════════════════
    // Lifecycle
    // ═══════════════════════════════════════════════════════════════

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_capture);

        showOverlay = getIntent().getBooleanExtra(EXTRA_SHOW_OVERLAY, true);
        executor = DitaAudit.getInstance().getExecutor();
        bindViews();
        setupListeners();
        setupBackPressHandler();
        initProcessor();

        if (!showOverlay) {
            detectionOverlay.setVisibility(View.GONE);
        }

        if (checkCameraPermission()) {
            startCamera();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().register(this);
        }
    }

    @Override
    protected void onStop() {
        if (processor != null) processor.release();
        if (EventBus.getDefault().isRegistered(this)) {
            EventBus.getDefault().unregister(this);
        }
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopTimer();
        if (!inspectionCompleted) cancelInspectionOnServer("APP_CLOSED");
        if (yoloDetector != null) yoloDetector.close();
        if (detectionOverlay != null) detectionOverlay.clear();
        analysisExecutor.shutdown();
    }

    private void setupBackPressHandler() {
        getOnBackPressedDispatcher().addCallback(this, new androidx.activity.OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                showCancelDialog();
            }
        });
    }

    // ═══════════════════════════════════════════════════════════════
    // Bind & Listeners (main thread)
    // ═══════════════════════════════════════════════════════════════

    private void bindViews() {
        previewView = findViewById(R.id.previewView);
        btnRecord = findViewById(R.id.btnRecord);
        btnClose = findViewById(R.id.btnClose);
        tvStepTitle = findViewById(R.id.tvStepTitle);
        tvStepDescription = findViewById(R.id.tvStepDescription);
        tvTimer = findViewById(R.id.tvTimer);
        tvRecordHint = findViewById(R.id.tvRecordHint);
        tvProcessingStatus = findViewById(R.id.tvProcessingStatus);
        stepDot1 = findViewById(R.id.stepDot1);
        stepDot2 = findViewById(R.id.stepDot2);
        overlayProcessing = findViewById(R.id.overlayProcessing);
        progressBar = findViewById(R.id.progressBar);
        progressBarHorizontal = findViewById(R.id.progressBarHorizontal);
        detectionOverlay = findViewById(R.id.detectionOverlay);
        tvCountdown = findViewById(R.id.tvCountdown);

        painelRoteiro = findViewById(R.id.painelRoteiro);
        tvLadoAtual = findViewById(R.id.tvLadoAtual);
        tvInstrucaoLado = findViewById(R.id.tvInstrucaoLado);
        tvProgressoRoteiro = findViewById(R.id.tvProgressoRoteiro);
        layoutChecklist = findViewById(R.id.layoutChecklist);
        captureGuide = new CaptureGuide();

        overlayResultado = findViewById(R.id.overlayResultado);
        tvResultScore = findViewById(R.id.tvResultScore);
        tvResultStatus = findViewById(R.id.tvResultStatus);
        tvResultResumo = findViewById(R.id.tvResultResumo);
        layoutVideoChecklists = findViewById(R.id.layoutVideoChecklists);
        findViewById(R.id.btnResultFechar).setOnClickListener(v -> fecharComResultado());
    }

    private void setupListeners() {
        btnRecord.setOnClickListener(v -> {
            if (isRecording) stopRecording();
            else iniciarCountdown();
        });
        btnClose.setOnClickListener(v -> showCancelDialog());
    }

    // ═══════════════════════════════════════════════════════════════
    // Câmera (CameraController — pipeline único)
    // ═══════════════════════════════════════════════════════════════

    private boolean checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            return true;
        }
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO},
                REQUEST_CAMERA_PERMISSION);
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startCamera();
            } else {
                notifyError(ErrorCode.CAMERA_PERMISSION_DENIED, getString(R.string.dita_camera_permission_required));
                finish();
            }
        }
    }

    private void initProcessor() {
        yoloDetector = new YoloDetector();
        analysisExecutor.execute(() -> yoloDetector.initialize(getApplicationContext()));
        processor = new VehiclePartProcessor(yoloDetector);
    }

    private void startCamera() {
        cameraController = new LifecycleCameraController(this);
        cameraController.setCameraSelector(CameraSelector.DEFAULT_BACK_CAMERA);
        cameraController.setEnabledUseCases(CameraController.VIDEO_CAPTURE | CameraController.IMAGE_ANALYSIS);
        cameraController.setVideoCaptureQualitySelector(QualitySelector.from(Quality.HD));
        cameraController.setImageAnalysisAnalyzer(analysisExecutor, processor);
        cameraController.setImageAnalysisBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST);
        cameraController.setImageAnalysisTargetSize(new CameraController.OutputSize(new Size(640, 480)));

        previewView.setController(cameraController);
        cameraController.bindToLifecycle(this);
        Log.i(TAG, "Câmera iniciada via CameraController");
    }

    // ═══════════════════════════════════════════════════════════════
    // EventBus — recebe eventos do Processor (main thread)
    // ═══════════════════════════════════════════════════════════════

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onDetection(DetectionEvent event) {
        if (showOverlay) {
            detectionOverlay.setDetections(event.getDetections(), event.getSourceWidth(), event.getSourceHeight());
        }

        if (isRecording && !event.getDetections().isEmpty() && captureGuide.estaRodando()) {
            captureGuide.registrarDeteccoes(event.getDetections());
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onNoDetectionTimeout(NoDetectionTimeoutEvent event) {
        if (!isRecording) return;
        cancelledByTimeout = true;
        stopRecording();
        showNoDetectionTimeout();
    }

    // ═══════════════════════════════════════════════════════════════
    // Gravação
    // ═══════════════════════════════════════════════════════════════

    private void iniciarCountdown() {
        btnRecord.setEnabled(false);
        tvCountdown.setVisibility(View.VISIBLE);
        tvCountdown.setAlpha(1f);

        tvCountdown.setText("3");
        tvCountdown.animate().alpha(0.3f).setDuration(900).start();

        uiHandler.postDelayed(() -> {
            tvCountdown.setText("2");
            tvCountdown.setAlpha(1f);
            tvCountdown.animate().alpha(0.3f).setDuration(900).start();
        }, 1000);

        uiHandler.postDelayed(() -> {
            tvCountdown.setText("1");
            tvCountdown.setAlpha(1f);
            tvCountdown.animate().alpha(0.3f).setDuration(900).start();
        }, 2000);

        uiHandler.postDelayed(() -> {
            tvCountdown.setVisibility(View.GONE);
            btnRecord.setEnabled(true);
            startRecording();
        }, 3000);
    }

    @SuppressWarnings("MissingPermission")
    private void startRecording() {
        if (cameraController == null) return;

        int stepNum = (currentStep == Step.VIDEO_1) ? 1 : 2;
        File outputFile = new File(getCacheDir(),
                "dita_video_" + stepNum + "_" + System.currentTimeMillis() + ".mp4");
        FileOutputOptions outputOptions = new FileOutputOptions.Builder(outputFile).build();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            notifyError(ErrorCode.CAMERA_PERMISSION_DENIED, "Permissão de áudio negada");
            return;
        }

        activeRecording = cameraController.startRecording(
                outputOptions,
                AudioConfig.create(true),
                ContextCompat.getMainExecutor(this),
                event -> {
                    if (event instanceof VideoRecordEvent.Start) {
                        onRecordingStarted();
                    } else if (event instanceof VideoRecordEvent.Finalize) {
                        VideoRecordEvent.Finalize fin = (VideoRecordEvent.Finalize) event;
                        if (!fin.hasError()) {
                            onRecordingFinished(outputFile);
                        } else {
                            Log.e(TAG, "Erro na gravação: " + fin.getError());
                            notifyError(ErrorCode.RECORDING_ERROR, "Erro na gravação do vídeo");
                        }
                    }
                });
    }

    private void onRecordingStarted() {
        isRecording = true;
        recordingStartTime = System.currentTimeMillis();
        cancelledByTimeout = false;
        processor.onRecordingStarted();

        btnRecord.setBackground(ContextCompat.getDrawable(this, R.drawable.dita_btn_record_active));
        tvRecordHint.setText(R.string.dita_tap_to_stop);
        tvTimer.setVisibility(View.VISIBLE);
        startTimer();
        iniciarRoteiro();
    }

    private void stopRecording() {
        if (activeRecording != null) {
            activeRecording.stop();
            activeRecording = null;
        }
        isRecording = false;
        processor.onRecordingStopped();
        stopTimer();
        pararRoteiro();

        btnRecord.setBackground(ContextCompat.getDrawable(this, R.drawable.dita_btn_record));
        tvRecordHint.setText(R.string.dita_tap_to_record);
    }

    private void onRecordingFinished(File videoFile) {
        isRecording = false;
        if (cancelledByTimeout) {
            if (videoFile.exists()) videoFile.delete();
            return;
        }

        if (currentStep == Step.VIDEO_1) {
            video1File = videoFile;
            moveToStep2();
        } else {
            video2File = videoFile;

            if (!processor.isVehicleDetected()) {
                showPreValidationFailure();
                return;
            }

            notifyProgress("PRE_APPROVED", 50);
            startUploadAndProcess();
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Etapas
    // ═══════════════════════════════════════════════════════════════

    private void moveToStep2() {
        currentStep = Step.VIDEO_2;
        tvStepTitle.setText(R.string.dita_video_2_title);
        tvStepDescription.setText(R.string.dita_video_2_desc);
        tvTimer.setVisibility(View.GONE);
        btnRecord.setBackground(ContextCompat.getDrawable(this, R.drawable.dita_btn_record));
        tvRecordHint.setText(R.string.dita_tap_to_record);
        stepDot1.setBackgroundResource(R.drawable.dita_bg_step_inactive);
        stepDot2.setBackgroundResource(R.drawable.dita_bg_step_active);
        notifyProgress("RECORDING_VIDEO_2", -1);
    }

    private void resetToStep1() {
        processor.reset();
        currentStep = Step.VIDEO_1;
        video1File = null;
        video2File = null;
        cancelledByTimeout = false;
        isRecording = false;
        activeRecording = null;

        tvStepTitle.setText(R.string.dita_video_1_title);
        tvStepDescription.setText(R.string.dita_video_1_desc);
        stepDot1.setBackgroundResource(R.drawable.dita_bg_step_active);
        stepDot2.setBackgroundResource(R.drawable.dita_bg_step_inactive);
        btnRecord.setVisibility(View.VISIBLE);
        btnRecord.setBackground(ContextCompat.getDrawable(this, R.drawable.dita_btn_record));
        tvRecordHint.setText(R.string.dita_tap_to_record);
        tvTimer.setVisibility(View.GONE);
        overlayProcessing.setVisibility(View.GONE);
        painelRoteiro.setVisibility(View.GONE);
    }

    // ═══════════════════════════════════════════════════════════════
    // Upload & Processamento (background thread)
    // ═══════════════════════════════════════════════════════════════

    private void startUploadAndProcess() {
        showProcessingOverlay(getString(R.string.dita_uploading));
        notifyProgress("UPLOADING", 0);

        executor.execute(() -> {
            try {
                UploadHelper helper = new UploadHelper(this, processor, video1File, video2File, recordingStartTime);
                helper.execute();
            } catch (Exception e) {
                String msg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
                Log.e(TAG, "Erro no upload/processamento: " + msg, e);
                cleanupFiles();
                runOnUiThread(() -> {
                    notifyError(ErrorCode.UPLOAD_FAILED, "Falha no envio: " + msg);
                    finish();
                });
            }
        });
    }

    /** Chamado pelo UploadHelper ao concluir com sucesso */
    void onUploadComplete(com.dita.audit.model.AuditResult result) {
        cleanupFiles();
        inspectionCompleted = true;

        if (DitaAudit.getInstance().getConfig().isShowResultScreen()) {
            ultimoResultado = result;
            runOnUiThread(() -> mostrarResultado(result));
        } else {
            DitaCallback cb = DitaAudit.getInstance().getCurrentCallback();
            if (cb != null) cb.onResult(result);
            runOnUiThread(this::finish);
        }
    }

    private void mostrarResultado(com.dita.audit.model.AuditResult result) {
        overlayProcessing.setVisibility(View.GONE);
        overlayResultado.setVisibility(View.VISIBLE);
        ResultViewHelper.preencher(
                result, tvResultScore, tvResultStatus,
                tvResultResumo, layoutVideoChecklists, this);
    }

    private void fecharComResultado() {
        DitaCallback cb = DitaAudit.getInstance().getCurrentCallback();
        if (cb != null && ultimoResultado != null) cb.onResult(ultimoResultado);
        finish();
    }

    // ═══════════════════════════════════════════════════════════════
    // Roteiro (checklist por lado)
    // ═══════════════════════════════════════════════════════════════

    private void iniciarRoteiro() {
        captureGuide.iniciar(new CaptureGuide.RoteiroListener() {
            @Override
            public void onFaseMudou(CaptureGuide.Fase fase, int numero, int total,
                                    java.util.List<CaptureGuide.ItemChecklist> checklist) {
                tvLadoAtual.setText(fase.nome);
                tvInstrucaoLado.setText(fase.instrucao);
                tvProgressoRoteiro.setText("Lado " + numero + " de " + total);
                atualizarChecklist(checklist);
                painelRoteiro.setVisibility(View.VISIBLE);
            }

            @Override
            public void onPecaDetectada(CaptureGuide.Fase fase, String peca,
                                        java.util.List<CaptureGuide.ItemChecklist> checklist) {
                atualizarChecklist(checklist);
            }

            @Override
            public void onFaseConcluida(CaptureGuide.Fase fase) { }

            @Override
            public void onRoteiroConcluido() {
                painelRoteiro.setVisibility(View.GONE);
            }
        });
    }

    private void pararRoteiro() {
        captureGuide.parar();
        painelRoteiro.setVisibility(View.GONE);
    }

    private void atualizarChecklist(java.util.List<CaptureGuide.ItemChecklist> items) {
        layoutChecklist.removeAllViews();
        for (CaptureGuide.ItemChecklist item : items) {
            TextView tv = new TextView(this);
            if (item.detectado) {
                tv.setText("✓  " + item.nomeExibicao);
                tv.setTextColor(0xFF4CAF50);
                tv.setTypeface(null, Typeface.BOLD);
            } else {
                tv.setText("○  " + item.nomeExibicao);
                tv.setTextColor(0xAAFFFFFF);
            }
            tv.setTextSize(12f);
            tv.setPadding(0, 2, 0, 2);
            layoutChecklist.addView(tv);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // Timer
    // ═══════════════════════════════════════════════════════════════

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            long elapsed = (System.currentTimeMillis() - recordingStartTime) / 1000;
            tvTimer.setText(String.format(Locale.getDefault(), "%d:%02d", elapsed / 60, elapsed % 60));
            uiHandler.postDelayed(this, 1000);
        }
    };

    private void startTimer() { uiHandler.post(timerRunnable); }
    private void stopTimer() { uiHandler.removeCallbacks(timerRunnable); }

    // ═══════════════════════════════════════════════════════════════
    // UI helpers
    // ═══════════════════════════════════════════════════════════════

    void showProcessingOverlay(String message) {
        cameraController.clearImageAnalysisAnalyzer();
        runOnUiThread(() -> {
            overlayProcessing.setVisibility(View.VISIBLE);
            tvProcessingStatus.setText(message);
            btnRecord.setVisibility(View.GONE);
            detectionOverlay.clear();
        });
    }

    void updateProcessingStatus(String message, int progress) {
        runOnUiThread(() -> {
            tvProcessingStatus.setText(message);
            if (progress >= 0) {
                progressBarHorizontal.setVisibility(View.VISIBLE);
                progressBarHorizontal.setProgress(progress);
            } else {
                progressBarHorizontal.setVisibility(View.GONE);
            }
        });
        notifyProgress("UPLOADING", progress);
    }

    private void showNoDetectionTimeout() {
        detectionOverlay.clear();
        cleanupFiles();
        new AlertDialog.Builder(this)
                .setTitle("Nenhum veículo detectado")
                .setMessage("Nenhuma peça foi detectada nos últimos 6 segundos.\n\n"
                        + "Certifique-se de apontar a câmera para o veículo.")
                .setPositiveButton("Tentar novamente", (d, w) -> resetToStep1())
                .setNegativeButton("Cancelar", (d, w) -> {
                    notifyError(ErrorCode.VEHICLE_NOT_DETECTED, "Nenhum veículo detectado durante a gravação");
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void showPreValidationFailure() {
        detectionOverlay.clear();
        cleanupFiles();
        int count = processor.getUniquePartsCount();
        new AlertDialog.Builder(this)
                .setTitle("Vistoria Rejeitada")
                .setMessage("Não foi possível identificar um veículo nos vídeos gravados.\n\n"
                        + "Peças detectadas: " + count + "/6 mínimas\n\n"
                        + "Certifique-se de filmar o veículo de perto, mostrando todas as partes.")
                .setPositiveButton("Tentar novamente", (d, w) -> resetToStep1())
                .setNegativeButton("Cancelar", (d, w) -> {
                    notifyError(ErrorCode.VEHICLE_NOT_DETECTED, "Veículo não identificado nos vídeos");
                    finish();
                })
                .setCancelable(false)
                .show();
    }

    private void showCancelDialog() {
        if (isRecording) stopRecording();
        new AlertDialog.Builder(this)
                .setTitle(R.string.dita_cancel_confirm_title)
                .setMessage(R.string.dita_cancel_confirm_message)
                .setPositiveButton(R.string.dita_cancel_yes, (d, w) -> {
                    cleanupFiles();
                    cancelInspectionOnServer("USER_CANCELLED");
                    inspectionCompleted = true;
                    notifyError(ErrorCode.CANCELLED, "Operação cancelada pelo usuário");
                    finish();
                })
                .setNegativeButton(R.string.dita_cancel_no, null)
                .show();
    }

    // ═══════════════════════════════════════════════════════════════
    // Utilitários
    // ═══════════════════════════════════════════════════════════════

    private void cleanupFiles() {
        if (video1File != null && video1File.exists()) video1File.delete();
        if (video2File != null && video2File.exists()) video2File.delete();
    }

    private void notifyError(ErrorCode code, String message) {
        DitaCallback callback = DitaAudit.getInstance().getCurrentCallback();
        if (callback != null) {
            runOnUiThread(() -> callback.onError(new DitaError(code, message)));
        }
    }

    private void notifyProgress(String stage, int progress) {
        DitaCallback callback = DitaAudit.getInstance().getCurrentCallback();
        if (callback != null) {
            runOnUiThread(() -> callback.onProgress(stage, progress));
        }
    }

    private void cancelInspectionOnServer(String reason) {
        String inspectionId = DitaAudit.getInstance().getCurrentInspectionId();
        com.dita.audit.internal.ApiClient api = DitaAudit.getInstance().getApiClient();
        if (inspectionId == null || api == null) return;
        new Thread(() -> api.cancelInspection(inspectionId, reason)).start();
    }
}
