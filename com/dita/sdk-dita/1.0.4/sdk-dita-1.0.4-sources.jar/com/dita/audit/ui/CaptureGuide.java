package com.dita.audit.ui;

import com.dita.audit.detection.Detection;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Roteiro de gravação: guia o vistoriador pelos lados do veículo (360°).
 *
 * <p>Sequência: DIANTEIRA → LAT. DIREITA (motorista) → TRASEIRA → LAT. ESQUERDA (passageiro) → DIANTEIRA (fechar 360°)</p>
 *
 * Cada lado tem um checklist de peças obrigatórias. Avança automaticamente
 * quando todas as peças do lado atual forem detectadas pela YOLO.
 * O mesmo roteiro é usado para ambos os vídeos (V1 fechado, V2 aberto).
 */
public class CaptureGuide {

    // ─── Fases e peças obrigatórias por lado ──────────────────

    public enum Fase {
        DIANTEIRA("Dianteira", "Filme a FRENTE do veículo",
                new String[]{"Hood", "Front-bumper", "Headlight", "Grille", "Windshield", "License-plate"}),

        LATERAL_DIREITA("Lat. Direita", "Contorne pelo lado do MOTORISTA",
                new String[]{"Front-door", "Back-door", "Mirror", "Front-wheel", "Back-wheel", "Fender"}),

        TRASEIRA("Traseira", "Filme a TRASEIRA do veículo",
                new String[]{"Back-bumper", "Tail-light", "Back-windshield", "Trunk"}),

        LATERAL_ESQUERDA("Lat. Esquerda", "Contorne pelo lado do PASSAGEIRO",
                new String[]{"Front-door", "Back-door", "Mirror", "Front-wheel", "Back-wheel", "Fender"}),

        DIANTEIRA_FINAL("Dianteira", "Volte para a FRENTE para fechar o 360°",
                new String[]{"Hood", "Front-bumper", "Headlight", "Windshield"});

        public final String nome;
        public final String instrucao;
        public final String[] pecas;

        Fase(String nome, String instrucao, String[] pecas) {
            this.nome = nome;
            this.instrucao = instrucao;
            this.pecas = pecas;
        }
    }

    /** Sequência dos 5 passos (4 lados + volta à dianteira) — mesma para V1 e V2 */
    private static final Fase[] SEQUENCIA = {
            Fase.DIANTEIRA, Fase.LATERAL_DIREITA, Fase.TRASEIRA, Fase.LATERAL_ESQUERDA, Fase.DIANTEIRA_FINAL
    };

    // ─── Estado interno ───────────────────────────────────────

    private int faseAtual = 0;
    private final Set<String> pecasDetectadas = new HashSet<>();
    private boolean rodando = false;
    private RoteiroListener listener;

    // ─── Callback ─────────────────────────────────────────────

    public interface RoteiroListener {
        /** Fase mudou — atualizar UI com novo lado e checklist */
        void onFaseMudou(Fase fase, int numero, int total, List<ItemChecklist> checklist);

        /** Peça detectada — atualizar checklist na UI */
        void onPecaDetectada(Fase fase, String peca, List<ItemChecklist> checklist);

        /** Todas as peças de um lado foram detectadas */
        void onFaseConcluida(Fase fase);

        /** Todos os 4 lados foram concluídos */
        void onRoteiroConcluido();
    }

    /** Item do checklist para a UI */
    public static class ItemChecklist {
        public final String label;
        public final String nomeExibicao;
        public final boolean detectado;

        public ItemChecklist(String label, String nomeExibicao, boolean detectado) {
            this.label = label;
            this.nomeExibicao = nomeExibicao;
            this.detectado = detectado;
        }
    }

    // ─── API pública ──────────────────────────────────────────

    /** Inicia o roteiro (mesmo para V1 ou V2) */
    public void iniciar(RoteiroListener listener) {
        this.listener = listener;
        this.faseAtual = 0;
        this.pecasDetectadas.clear();
        this.rodando = true;
        notificarFase();
    }

    /** Para o roteiro */
    public void parar() {
        rodando = false;
    }

    /** Retorna se está rodando */
    public boolean estaRodando() {
        return rodando;
    }

    /** Retorna a fase atual (ou null se concluído) */
    public Fase getFaseAtual() {
        if (faseAtual >= SEQUENCIA.length) return null;
        return SEQUENCIA[faseAtual];
    }

    /**
     * Registra detecções YOLO de um frame.
     * Se alguma peça pertence ao checklist do lado atual, marca como detectada.
     * Se todas foram detectadas, avança pro próximo lado automaticamente.
     */
    public void registrarDeteccoes(List<Detection> detections) {
        if (!rodando || faseAtual >= SEQUENCIA.length) return;

        Fase fase = SEQUENCIA[faseAtual];
        boolean algumaNova = false;

        for (Detection det : detections) {
            String label = det.getLabel();
            if (pecasDetectadas.contains(label)) continue;

            // Verificar se a peça pertence ao lado atual
            for (String peca : fase.pecas) {
                if (peca.equals(label)) {
                    pecasDetectadas.add(label);
                    algumaNova = true;
                    break;
                }
            }
        }

        if (!algumaNova) return;

        List<ItemChecklist> checklist = montarChecklist();

        if (listener != null) {
            listener.onPecaDetectada(fase, "", checklist);
        }

        // Todas as peças do lado atual foram detectadas?
        if (pecasDetectadas.size() >= fase.pecas.length) {
            if (listener != null) listener.onFaseConcluida(fase);
            avancar();
        }
    }

    // ─── Interno ──────────────────────────────────────────────

    private void avancar() {
        faseAtual++;
        pecasDetectadas.clear();

        if (faseAtual >= SEQUENCIA.length) {
            rodando = false;
            if (listener != null) listener.onRoteiroConcluido();
        } else {
            notificarFase();
        }
    }

    private void notificarFase() {
        if (faseAtual >= SEQUENCIA.length) return;
        Fase fase = SEQUENCIA[faseAtual];
        List<ItemChecklist> checklist = montarChecklist();
        if (listener != null) {
            listener.onFaseMudou(fase, faseAtual + 1, SEQUENCIA.length, checklist);
        }
    }

    private List<ItemChecklist> montarChecklist() {
        Fase fase = SEQUENCIA[faseAtual];
        List<ItemChecklist> items = new ArrayList<>();
        for (String peca : fase.pecas) {
            items.add(new ItemChecklist(
                    peca,
                    Detection.displayNameFor(peca),
                    pecasDetectadas.contains(peca)
            ));
        }
        return items;
    }
}
