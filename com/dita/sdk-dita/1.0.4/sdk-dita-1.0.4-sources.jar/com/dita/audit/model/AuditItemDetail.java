package com.dita.audit.model;

/**
 * Detalhe de um item detectado na auditoria.
 */
public class AuditItemDetail {

    private final String part;
    private final boolean detected;
    private final double confidence;
    private final String side;

    public AuditItemDetail(String part, boolean detected, double confidence, String side) {
        this.part = part;
        this.detected = detected;
        this.confidence = confidence;
        this.side = side;
    }

    public String getPart() { return part; }
    public boolean isDetected() { return detected; }
    public double getConfidence() { return confidence; }
    public String getSide() { return side; }

    @Override
    public String toString() {
        return part + " (" + (detected ? Math.round(confidence * 100) + "%" : "não detectado") + ")";
    }
}
