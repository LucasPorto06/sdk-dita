package com.dita.audit.detection;

import android.graphics.RectF;

import java.util.ArrayList;
import java.util.List;

/**
 * Suaviza transições de bounding boxes entre frames consecutivos.
 * Usa IoU (Intersection over Union) pra associar detecções entre frames
 * e EMA (Exponential Moving Average) pra interpolar posição.
 * Suporta múltiplas instâncias da mesma classe (ex: 2 faróis).
 */
public class BoxSmoother {

    /** Fator de suavização: 0 = sem mudança, 1 = sem smoothing */
    private static final float ALPHA = 0.4f;

    /** IoU mínimo pra considerar que é o mesmo objeto */
    private static final float IOU_MINIMO = 0.2f;

    /** Frames sem detecção antes de remover o box */
    private static final int MAX_FRAMES_SEM_DETECCAO = 1;

    /** Próximo ID único pra rastrear cada box */
    private int proximoId = 0;

    /** Lista de boxes rastreados ativos */
    private final List<BoxEstado> ativos = new ArrayList<>();

    /**
     * Recebe as detecções brutas do frame atual e retorna detecções suavizadas.
     */
    public List<Detection> suavizar(List<Detection> deteccoesNovas) {
        // Marca todos como "não pareado"
        for (BoxEstado estado : ativos) {
            estado.pareado = false;
        }

        // Pra cada detecção nova, encontra o box ativo mais próximo (mesmo classId + maior IoU)
        boolean[] usada = new boolean[deteccoesNovas.size()];

        for (BoxEstado estado : ativos) {
            float melhorIou = IOU_MINIMO;
            int melhorIdx = -1;

            for (int i = 0; i < deteccoesNovas.size(); i++) {
                if (usada[i]) continue;
                Detection det = deteccoesNovas.get(i);

                // Só pareia com mesma classe
                if (det.getClassId() != estado.classId) continue;

                float iou = calcularIoU(estado, det.getBoundingBox());
                if (iou > melhorIou) {
                    melhorIou = iou;
                    melhorIdx = i;
                }
            }

            if (melhorIdx >= 0) {
                estado.interpolar(deteccoesNovas.get(melhorIdx));
                estado.pareado = true;
                estado.framesSemDeteccao = 0;
                usada[melhorIdx] = true;
            }
        }

        // Detecções não pareadas viram novos boxes rastreados
        for (int i = 0; i < deteccoesNovas.size(); i++) {
            if (!usada[i]) {
                ativos.add(new BoxEstado(proximoId++, deteccoesNovas.get(i)));
            }
        }

        // Remove boxes que ficaram sem detecção por muitos frames
        List<BoxEstado> remover = new ArrayList<>();
        for (BoxEstado estado : ativos) {
            if (!estado.pareado) {
                estado.framesSemDeteccao++;
                if (estado.framesSemDeteccao > MAX_FRAMES_SEM_DETECCAO) {
                    remover.add(estado);
                }
            }
        }
        ativos.removeAll(remover);

        // Monta resultado
        List<Detection> resultado = new ArrayList<>(ativos.size());
        for (BoxEstado estado : ativos) {
            resultado.add(estado.toDetection());
        }
        return resultado;
    }

    /** Limpa todo o estado acumulado */
    public void limpar() {
        ativos.clear();
        proximoId = 0;
    }

    /** Calcula IoU entre um box rastreado e um RectF novo */
    private float calcularIoU(BoxEstado estado, RectF box) {
        float interLeft = Math.max(estado.left, box.left);
        float interTop = Math.max(estado.top, box.top);
        float interRight = Math.min(estado.right, box.right);
        float interBottom = Math.min(estado.bottom, box.bottom);

        float interArea = Math.max(0, interRight - interLeft) * Math.max(0, interBottom - interTop);
        if (interArea == 0) return 0;

        float areaEstado = (estado.right - estado.left) * (estado.bottom - estado.top);
        float areaBox = (box.right - box.left) * (box.bottom - box.top);
        float unionArea = areaEstado + areaBox - interArea;

        return unionArea > 0 ? interArea / unionArea : 0;
    }

    /**
     * Estado interno de um box rastreado.
     */
    private static class BoxEstado {
        final int id;
        int classId;
        String label;
        float confidence;
        float left, top, right, bottom;
        boolean pareado;
        int framesSemDeteccao;

        BoxEstado(int id, Detection det) {
            this.id = id;
            this.classId = det.getClassId();
            this.label = det.getLabel();
            this.confidence = det.getConfidence();
            RectF box = det.getBoundingBox();
            this.left = box.left;
            this.top = box.top;
            this.right = box.right;
            this.bottom = box.bottom;
        }

        void interpolar(Detection det) {
            RectF box = det.getBoundingBox();
            this.left = ALPHA * box.left + (1 - ALPHA) * this.left;
            this.top = ALPHA * box.top + (1 - ALPHA) * this.top;
            this.right = ALPHA * box.right + (1 - ALPHA) * this.right;
            this.bottom = ALPHA * box.bottom + (1 - ALPHA) * this.bottom;
            this.confidence = ALPHA * det.getConfidence() + (1 - ALPHA) * this.confidence;
            this.label = det.getLabel();
        }

        Detection toDetection() {
            return new Detection(classId, label, confidence,
                    new RectF(left, top, right, bottom));
        }
    }
}
