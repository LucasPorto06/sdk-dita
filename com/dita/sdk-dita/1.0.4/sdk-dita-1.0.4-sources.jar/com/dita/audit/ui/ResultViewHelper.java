package com.dita.audit.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.dita.audit.model.AuditResult;
import com.dita.audit.model.AuditStatus;
import com.dita.audit.model.VideoChecklist;

/**
 * Monta a view de resultado da auditoria com score, status e checklists por vídeo.
 * Classe utilitária — mantém a CaptureActivity enxuta.
 */
class ResultViewHelper {

    private static final int COR_VERDE = 0xFF4CAF50;
    private static final int COR_AMARELO = 0xFFFF9800;
    private static final int COR_VERMELHO = 0xFFE53935;
    private static final int COR_TEXTO = 0xFF1A1A1A;
    private static final int COR_TEXTO_SECUNDARIO = 0xFF777777;

    private ResultViewHelper() { }

    /**
     * Preenche as views do overlay de resultado com os dados do AuditResult.
     */
    static void preencher(
            AuditResult result,
            TextView tvScore,
            TextView tvStatus,
            TextView tvResumo,
            LinearLayout layoutChecklists,
            Context context
    ) {
        // Score com cor
        int score = result.getScore();
        tvScore.setText(score + "/100");
        tvScore.setTextColor(corDoScore(score));

        // Status
        AuditStatus status = result.getStatus();
        tvStatus.setText(status.getLabel());
        tvStatus.setTextColor(corDoStatus(status));

        // Resumo
        String summary = result.getSummary();
        if (summary != null && !summary.isEmpty()) {
            tvResumo.setText(summary);
            tvResumo.setVisibility(View.VISIBLE);
        } else {
            tvResumo.setVisibility(View.GONE);
        }

        // Checklists por vídeo
        layoutChecklists.removeAllViews();
        for (VideoChecklist vc : result.getVideoChecklists()) {
            layoutChecklists.addView(criarCardVideo(vc, context));
        }
    }

    /**
     * Cria um card com o checklist de um vídeo.
     */
    private static View criarCardVideo(VideoChecklist vc, Context context) {
        LinearLayout card = new LinearLayout(context);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(0xFFF5F5F5);
        card.setPadding(dp(context, 16), dp(context, 12), dp(context, 16), dp(context, 12));

        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dp(context, 12));
        card.setLayoutParams(cardParams);

        // Cabeçalho: label + badge
        LinearLayout header = new LinearLayout(context);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvLabel = new TextView(context);
        tvLabel.setText(vc.getLabel());
        tvLabel.setTextSize(15);
        tvLabel.setTextColor(COR_TEXTO);
        tvLabel.setTypeface(null, Typeface.BOLD);
        tvLabel.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        header.addView(tvLabel);

        // Badge: "DONE" ou "19/21"
        TextView tvBadge = new TextView(context);
        tvBadge.setTextSize(12);
        tvBadge.setTypeface(null, Typeface.BOLD);
        tvBadge.setPadding(dp(context, 8), dp(context, 2), dp(context, 8), dp(context, 2));
        if (vc.isCompleto()) {
            tvBadge.setText("DONE");
            tvBadge.setTextColor(0xFFFFFFFF);
            tvBadge.setBackgroundColor(COR_VERDE);
        } else {
            tvBadge.setText(vc.getResumo());
            tvBadge.setTextColor(COR_TEXTO_SECUNDARIO);
            tvBadge.setBackgroundColor(0xFFE0E0E0);
        }
        header.addView(tvBadge);
        card.addView(header);

        // Separador
        View sep = new View(context);
        sep.setBackgroundColor(0xFFDDDDDD);
        LinearLayout.LayoutParams sepParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(context, 1));
        sepParams.setMargins(0, dp(context, 8), 0, dp(context, 8));
        sep.setLayoutParams(sepParams);
        card.addView(sep);

        // Label "CHECKLIST" + contagem
        LinearLayout checkHeader = new LinearLayout(context);
        checkHeader.setOrientation(LinearLayout.HORIZONTAL);
        checkHeader.setGravity(Gravity.CENTER_VERTICAL);

        TextView tvCheck = new TextView(context);
        tvCheck.setText("CHECKLIST");
        tvCheck.setTextSize(11);
        tvCheck.setTextColor(COR_TEXTO_SECUNDARIO);
        tvCheck.setTypeface(null, Typeface.BOLD);
        tvCheck.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        checkHeader.addView(tvCheck);

        TextView tvCount = new TextView(context);
        tvCount.setText(vc.getResumo());
        tvCount.setTextSize(11);
        tvCount.setTextColor(COR_TEXTO_SECUNDARIO);
        checkHeader.addView(tvCount);

        card.addView(checkHeader);

        // Grid de peças (2 colunas)
        LinearLayout grid = new LinearLayout(context);
        grid.setOrientation(LinearLayout.HORIZONTAL);

        LinearLayout col1 = new LinearLayout(context);
        col1.setOrientation(LinearLayout.VERTICAL);
        col1.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        LinearLayout col2 = new LinearLayout(context);
        col2.setOrientation(LinearLayout.VERTICAL);
        col2.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        int half = (vc.getParts().size() + 1) / 2;
        for (int i = 0; i < vc.getParts().size(); i++) {
            VideoChecklist.PartDetection part = vc.getParts().get(i);
            View row = criarLinhaChecklist(part, context);
            if (i < half) {
                col1.addView(row);
            } else {
                col2.addView(row);
            }
        }

        grid.addView(col1);
        grid.addView(col2);
        card.addView(grid);

        return card;
    }

    /**
     * Cria uma linha do checklist: "● Nome da Peça    95%"
     */
    private static View criarLinhaChecklist(VideoChecklist.PartDetection part, Context context) {
        LinearLayout row = new LinearLayout(context);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(context, 3), 0, dp(context, 3));

        // Ícone (bolinha verde ou cinza)
        TextView tvIcon = new TextView(context);
        tvIcon.setTextSize(10);
        if (part.isDetected()) {
            tvIcon.setText("●");
            tvIcon.setTextColor(COR_VERDE);
        } else {
            tvIcon.setText("○");
            tvIcon.setTextColor(0xFFBBBBBB);
        }
        tvIcon.setPadding(0, 0, dp(context, 6), 0);
        row.addView(tvIcon);

        // Nome da peça
        TextView tvNome = new TextView(context);
        tvNome.setText(part.getDisplayName());
        tvNome.setTextSize(12);
        tvNome.setTextColor(part.isDetected() ? COR_TEXTO : COR_TEXTO_SECUNDARIO);
        tvNome.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        row.addView(tvNome);

        // Confiança
        if (part.isDetected()) {
            TextView tvConf = new TextView(context);
            tvConf.setText(part.getConfidenceFormatted());
            tvConf.setTextSize(11);
            tvConf.setTextColor(COR_TEXTO_SECUNDARIO);
            row.addView(tvConf);
        }

        return row;
    }

    private static int corDoScore(int score) {
        if (score >= 80) return COR_VERDE;
        if (score >= 60) return COR_AMARELO;
        return COR_VERMELHO;
    }

    private static int corDoStatus(AuditStatus status) {
        switch (status) {
            case APPROVED: return COR_VERDE;
            case REJECTED: return COR_VERMELHO;
            case NEEDS_REVIEW: return COR_AMARELO;
            default: return COR_TEXTO_SECUNDARIO;
        }
    }

    private static int dp(Context context, int dp) {
        return (int) (dp * context.getResources().getDisplayMetrics().density);
    }
}
