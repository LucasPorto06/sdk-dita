package com.dita.audit.callback;

import com.dita.audit.model.ErrorCode;

/**
 * Representa um erro ocorrido durante o fluxo do SDK.
 */
public class DitaError {

    private final ErrorCode code;
    private final String message;
    private final Throwable cause;

    public DitaError(ErrorCode code, String message) {
        this(code, message, null);
    }

    public DitaError(ErrorCode code, String message, Throwable cause) {
        this.code = code;
        this.message = message;
        this.cause = cause;
    }

    public ErrorCode getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public Throwable getCause() {
        return cause;
    }

    @Override
    public String toString() {
        return "DitaError{code=" + code.getKey() + " (" + code.getLabel() + "), message='" + message + "'}";
    }
}
