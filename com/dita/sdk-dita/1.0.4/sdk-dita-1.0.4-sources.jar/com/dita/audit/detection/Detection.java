package com.dita.audit.detection;

import android.graphics.RectF;

import java.util.HashMap;
import java.util.Map;

/**
 * Representa uma detecção de peça de veículo feita pela YOLO on-device.
 */
public class Detection {

    private final int classId;
    private final String label;
    private final float confidence;
    private final RectF boundingBox;

    public Detection(int classId, String label, float confidence, RectF boundingBox) {
        this.classId = classId;
        this.label = label;
        this.confidence = confidence;
        this.boundingBox = boundingBox;
    }

    public int getClassId() { return classId; }
    public String getLabel() { return label; }
    public float getConfidence() { return confidence; }
    public RectF getBoundingBox() { return boundingBox; }

    @Override
    public String toString() {
        return label + " (" + String.format("%.0f%%", confidence * 100) + ")";
    }

    /** Labels das 21 classes do modelo YOLO (ordem do treinamento) */
    public static final String[] LABELS = {
            "Back-bumper", "Back-door", "Back-wheel", "Back-window",
            "Back-windshield", "Fender", "Front-bumper", "Front-door",
            "Front-wheel", "Front-window", "Grille", "Headlight",
            "Hood", "License-plate", "Mirror", "Quarter-panel",
            "Rocker-panel", "Roof", "Tail-light", "Trunk", "Windshield"
    };

    /** Nomes em pt-BR para exibição no overlay e UI */
    private static final Map<String, String> DISPLAY_NAMES = new HashMap<>();
    static {
        DISPLAY_NAMES.put("Back-bumper", "Para-choque Tras.");
        DISPLAY_NAMES.put("Back-door", "Porta Traseira");
        DISPLAY_NAMES.put("Back-wheel", "Roda Traseira");
        DISPLAY_NAMES.put("Back-window", "Vidro Tras. Lat.");
        DISPLAY_NAMES.put("Back-windshield", "Vigia Traseiro");
        DISPLAY_NAMES.put("Fender", "Para-lama");
        DISPLAY_NAMES.put("Front-bumper", "Para-choque Diant.");
        DISPLAY_NAMES.put("Front-door", "Porta Dianteira");
        DISPLAY_NAMES.put("Front-wheel", "Roda Dianteira");
        DISPLAY_NAMES.put("Front-window", "Vidro Diant. Lat.");
        DISPLAY_NAMES.put("Grille", "Grade");
        DISPLAY_NAMES.put("Headlight", "Farol");
        DISPLAY_NAMES.put("Hood", "Capô");
        DISPLAY_NAMES.put("License-plate", "Placa");
        DISPLAY_NAMES.put("Mirror", "Retrovisor");
        DISPLAY_NAMES.put("Quarter-panel", "Painel Lat. Tras.");
        DISPLAY_NAMES.put("Rocker-panel", "Soleira");
        DISPLAY_NAMES.put("Roof", "Teto");
        DISPLAY_NAMES.put("Tail-light", "Lanterna Traseira");
        DISPLAY_NAMES.put("Trunk", "Porta-malas");
        DISPLAY_NAMES.put("Windshield", "Para-brisa");
    }

    /** Retorna o label para um classId */
    public static String labelFor(int classId) {
        if (classId >= 0 && classId < LABELS.length) return LABELS[classId];
        return "class_" + classId;
    }

    /** Retorna o nome em pt-BR para exibição */
    public String getDisplayName() {
        String name = DISPLAY_NAMES.get(label);
        return name != null ? name : label;
    }

    /** Retorna o nome em pt-BR para um label */
    public static String displayNameFor(String label) {
        String name = DISPLAY_NAMES.get(label);
        return name != null ? name : label;
    }
}
