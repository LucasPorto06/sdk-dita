package com.dita.audit.model;

/**
 * Breakdown detalhado do score da auditoria.
 * Cada sub-score vai de 0 a 100.
 */
public class ScoreBreakdown {

    private final int coverage360;
    private final int criticalItems;
    private final int checklistGeneral;
    private final int avgConfidence;
    private final int finalScore;

    public ScoreBreakdown(int coverage360, int criticalItems, int checklistGeneral,
                          int avgConfidence, int finalScore) {
        this.coverage360 = coverage360;
        this.criticalItems = criticalItems;
        this.checklistGeneral = checklistGeneral;
        this.avgConfidence = avgConfidence;
        this.finalScore = finalScore;
    }

    /** Cobertura 360° — quantos lados do veículo foram filmados (peso 25%) */
    public int getCoverage360() { return coverage360; }

    /** Itens críticos detectados — peças obrigatórias por lado (peso 35%) */
    public int getCriticalItems() { return criticalItems; }

    /** Checklist geral — peças desejáveis detectadas (peso 25%) */
    public int getChecklistGeneral() { return checklistGeneral; }

    /** Confiança média das detecções (peso 15%) */
    public int getAvgConfidence() { return avgConfidence; }

    /** Score final composto (0-100) */
    public int getFinalScore() { return finalScore; }

    @Override
    public String toString() {
        return "ScoreBreakdown{" +
                "360°=" + coverage360 +
                ", criticos=" + criticalItems +
                ", checklist=" + checklistGeneral +
                ", confianca=" + avgConfidence +
                ", final=" + finalScore +
                '}';
    }
}
